# GLM — Entregables Nuevos (2026-07-18)

**Sesión:** 2026-07-13 a 2026-07-18
**Autor:** GLM (Integration Auditor / Arquitecto de Evolución / Runtime Engineer)
**Para:** Arquitecto y agentes (Qwen, Cascade, Claude A, Runtime Engineer)

---

## Qué contiene este zip

| Archivo | Líneas / Tamaño | Descripción |
|---|---|---|
| `SAGE_PLAN_ACTUAL.md` | 571 líneas / 27 KB | Único documento de seguimiento del plan SAGE. Reemplaza a todos los anteriores. Incluye explicaciones detalladas de funcionamiento de cada ítem de Fase 0. |
| `INSTRUCCIONES_AGENTES.md` | 206 líneas / 11 KB | Instrucciones concretas para cada agente (Qwen, Cascade, Claude A, Runtime Engineer, Arquitecto) sobre qué hacer con el `kernel/core.py` modificado. |
| `kernel/core.py` | 371 líneas / 16 KB | Único archivo de código modificado. Contiene el fix B-1 (wiring `set_agent_router`) aplicado sobre `sage_runtime_LISTO.zip`. |

---

## Orden de lectura recomendado

1. **`SAGE_PLAN_ACTUAL.md`** — empezar acá. Es el documento único de seguimiento. Reemplaza a `SAGE_STATUS_REPORT.md`, `MERGE_AUDIT.md`, `ROADMAP_V2.md`, `NEW_MODULES_PROPOSAL.md`, `PLUGIN_SYSTEM_VISION.md`, `RFC_FUTURE_MODULES.md`, `SAGE_V2_ARCHITECTURE.md`, y todos los documentos `CASCADE_*.md`. Esos ya no son referencia activa.

2. **`INSTRUCCIONES_AGENTES.md`** — después de leer el plan, leer las instrucciones específicas para cada agente. Indica qué debe hacer cada uno con el `kernel/core.py` modificado y qué pendientes tiene.

3. **`kernel/core.py`** — el archivo técnico. Reemplaza la versión local de cada agente. Verificar con `grep "set_agent_router(agent_router)" kernel/core.py` — debe devolver 1 ocurrencia.

---

## Estado resumido

### Fase 0 (7 ítems)

| ID | Estado |
|---|---|
| F0-1 System prompt | ❌ Pendiente |
| F0-2 WebSocket real | ⚠️ Parcial (heartbeat, no eventos) |
| F0-3 dispatch() devuelve resultado | ✅ Verificado |
| F0-4 CLI extrae 'output' | ✅ Verificado |
| F0-5 REST API extrae 'output' | ✅ Verificado |
| F0-6 Wiring set_agent_router | ✅ Verificado (en kernel/core.py) |
| F0-7 Smoke test Ollama real | ❌ Pendiente (solo Arquitecto) |

### Fase 1 (13 features)

⚠️ Plan de Cascade no confirmado. Resecuenciado por GLM es propuesta, no plan aprobado.

### Fase 2/3 (30 features)

🚫 DIFERIDA — sin fecha, sin orden, sin asignatario.

---

## Reglas críticas

1. `SAGE_PLAN_ACTUAL.md` es la **única** referencia activa. Todo lo demás es histórico.
2. Solo Qwen confirma ítems. Reports de Cascade/Devin sin verificar = "claimado, no verificado".
3. No se generan más roadmaps, RFCs, ni visiones v2 esta ronda.
4. Nadie fusiona ramas sin autorización explícita del Arquitecto.
5. `sage_runtime_LISTO.zip` + este `kernel/core.py` = fuente de verdad. El `Sage-main (3).zip` del GitHub está fragmentado y no se usa.

— GLM
