# SAGE Runtime v4.5 - Architecture Overview

**Version:** 4.5  
**Status:** Production-Ready  
**Architecture Status:** FROZEN  
**Last Updated:** July 2026

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Architecture Principles](#architecture-principles)
3. [Core Components](#core-components)
4. [System State Machine](#system-state-machine)
5. [Module Dependency Graph](#module-dependency-graph)
6. [Integration Points](#integration-points)

---

## Executive Summary

**SAGE Runtime v4.5** is a local Python-based execution environment for the SAGE OS architecture, extracted from the Opal implementation. This is **NOT a redesign** — it is a faithful migration preserving all existing execution flows, state transitions, and architectural patterns.

### Key Metrics

| Metric | Value |
|--------|-------|
| **Total Python Modules** | 63 |
| **Lines of Code** | 9,807 |
| **Core Components** | 14 |
| **API Endpoints** | 25+ |
| **Supported Agents** | 13 |
| **File Formats Supported** | 7 |
| **Programming Languages Detected** | 12+ |

### Core Capabilities

- ✅ **Multi-LLM Provider Support** - Grok, Gemini with automatic fallback
- ✅ **Comprehensive File Processing** - PDF, DOCX, TXT, ZIP, Images, Code
- ✅ **Repository Analysis** - AST parsing, language detection, dependency graphing
- ✅ **Code Quality Auditing** - Security, quality, dependencies, architecture
- ✅ **Image Analysis** - LLM-powered descriptions, OCR, classification
- ✅ **Multi-Agent Execution** - Parallel task dispatch and result aggregation
- ✅ **Real-Time Monitoring** - Dashboard with agent status and mission tracking
- ✅ **Persistent Memory** - SQLite with automatic checkpointing

---

## Architecture Principles

### 1. Frozen Architecture

The SAGE OS v4.5 architecture is **FROZEN**. All design decisions are preserved from the original Opal implementation:

- No architectural redesigns
- No simplifications or abstractions
- No new concepts or patterns
- Exact behavior preservation

### 2. Modular Design

Each component is self-contained with clear responsibilities:

```
┌─────────────────────────────────────────┐
│          SAGE Kernel (Core)             │
├─────────────────────────────────────────┤
│ ┌─────────┬────────┬────────┬─────────┐ │
│ │ Memory  │ Events │Dispatch│ Agents  │ │
│ └─────────┴────────┴────────┴─────────┘ │
│ ┌─────────┬────────┬────────┬─────────┐ │
│ │ Auditor │ Config │ Boot   │ Recovery│ │
│ └─────────┴────────┴────────┴─────────┘ │
│ ┌─────────┬────────┬────────┬─────────┐ │
│ │Provider │ Files  │ Repo   │ Image   │ │
│ └─────────┴────────┴────────┴─────────┘ │
└─────────────────────────────────────────┘
```

### 3. Async-First Design

All I/O operations use async/await:

- Non-blocking file operations
- Concurrent task execution
- WebSocket real-time updates
- Efficient resource utilization

### 4. Environment-Based Configuration

All sensitive configuration via environment variables:

- `GEMINI_API_KEY` - Google Gemini API
- `GROK_API_KEY` - xAI Grok API
- No hardcoded credentials
- Easy deployment across environments

---

## Core Components

### 1. Kernel (kernel/)

**Purpose:** Central orchestrator managing system lifecycle

**Files:**
- `kernel/core.py` - Main kernel class with boot sequence
- `kernel/state.py` - State machine implementation

**Responsibilities:**
- System initialization and shutdown
- Component lifecycle management
- State transitions
- Command execution routing

**Key Classes:**
- `SageKernel` - Main kernel orchestrator
- `KernelState` - Enumeration of kernel states

**State Flow:**
```
BOOT → KERNEL_READY → COMMAND_MODE → WAITING_FOR_USER_COMMAND
  ↓                                           ↑
  └─────────────────────────────────────────┘
                COMMAND_EXECUTION
```

---

### 2. Memory System (memory/)

**Purpose:** Persistent engineering memory with SQLite backend

**Files:**
- `memory/engine.py` - SQLite memory engine
- `memory/models.py` - Data models

**Features:**
- Automatic checkpointing (5-minute intervals)
- Session recovery
- PR history tracking
- Engineering record persistence

**Key Classes:**
- `MemoryEngine` - SQLite persistence layer
- `MemoryRecord` - Individual memory entries
- `SessionRecord` - Session state
- `PRRecord` - Pull request history

**Storage Location:** `~/.sage_os/memory.db`

---

### 3. Event Bus (events/)

**Purpose:** System-wide publish-subscribe event communication

**Files:**
- `events/bus.py` - Event bus implementation
- `events/models.py` - Event data models

**Features:**
- Async event publishing
- Multiple subscriber support
- Event history tracking
- Type-safe event handling

**Key Classes:**
- `EventBus` - Central event dispatcher
- `Event` - Event data structure
- `EventHandler` - Callback type

---

### 4. Task Dispatcher (dispatcher/)

**Purpose:** Priority-based async task execution

**Files:**
- `dispatcher/engine.py` - Task execution engine
- `dispatcher/models.py` - Task models

**Features:**
- Priority-based queuing
- Async task execution
- Multi-agent task dispatch
- Result aggregation

**Key Classes:**
- `TaskDispatcher` - Main task engine
- `Task` - Task definition
- `TaskStatus` - Task state enumeration

---

### 5. Agent Router (agents/)

**Purpose:** Multi-agent orchestration and routing

**Files:**
- `agents/router.py` - Agent routing logic
- `agents/models.py` - Agent data models

**Supported Agents:**
1. SAGE (Primary coordinator)
2. Jules (Optimization specialist)
3. Antigravity (Memory systems)
4. Cascade (Current execution agent)
5. Devin (Collaboration agent)
6. Local Ollama (Local models)
7. Gemini (Placeholder)
8. Cursor (Placeholder)
9. Codex (Placeholder)
10. Cline (Placeholder)
11. VS Code (Placeholder)
12. Copilot (Placeholder)
13. Perplexity (Placeholder)

**Key Classes:**
- `AgentRouter` - Agent management
- `Agent` - Agent definition
- `AgentType` - Agent type enumeration

---

### 6. Provider Layer (providers/)

**Purpose:** Multi-LLM provider abstraction with fallback

**Files:**
- `providers/base_provider.py` - Abstract provider interface
- `providers/gemini_provider.py` - Google Gemini implementation
- `providers/grok_provider.py` - xAI Grok implementation
- `providers/provider_router.py` - Provider selection logic

**Features:**
- Automatic provider fallback
- Unified API interface
- Environment-based configuration
- Streaming response support

**Key Classes:**
- `BaseProvider` - Abstract provider
- `GeminiProvider` - Gemini implementation
- `GrokProvider` - Grok implementation
- `ProviderRouter` - Provider selection

---

### 7. File Processing (file_processor/)

**Purpose:** Multi-format file parsing and extraction

**Files:**
- `file_processor/processor.py` - Main file processor
- `file_processor/parsers/pdf_parser.py` - PDF extraction
- `file_processor/parsers/docx_parser.py` - DOCX extraction
- `file_processor/parsers/text_parser.py` - Text parsing
- `file_processor/parsers/zip_parser.py` - ZIP handling
- `file_processor/parsers/image_parser.py` - Image metadata
- `file_processor/parsers/code_parser.py` - Code analysis

**Supported Formats:**
- PDF (text extraction)
- DOCX (document parsing)
- TXT/Markdown (text files)
- ZIP (archive handling)
- Images (metadata, classification)
- Source Code (language detection, structure)

**Key Classes:**
- `FileProcessor` - Main processor
- `PDFParser`, `DocxParser`, `TextParser`, etc. - Format-specific parsers

---

### 8. Repository Scanner (repository_scanner/)

**Purpose:** Recursive repository analysis with AST parsing

**Files:**
- `repository_scanner/scanner.py` - Main scanner
- `repository_scanner/language_detector.py` - Language detection
- `repository_scanner/ast_parser.py` - AST parsing
- `repository_scanner/dependency_graph.py` - Dependency analysis

**Features:**
- Recursive directory traversal
- Multi-language support (Python, JavaScript, Java, Go, Rust, etc.)
- AST-based function/class extraction
- Import dependency graphing
- Repository summarization

**Key Classes:**
- `RepositoryScanner` - Main scanner
- `LanguageDetector` - Language identification
- `ASTParser` - AST parsing
- `DependencyGraph` - Dependency analysis

---

### 9. Engineering Auditor (auditor/)

**Purpose:** Code quality, security, and architectural auditing

**Files:**
- `auditor/engine.py` - Audit engine
- `auditor/models.py` - Audit data models

**Audit Types:**
- Code Quality (line length, TODO/FIXME, complexity)
- Security (hardcoded secrets, dangerous functions)
- Dependencies (vulnerable packages)
- Architecture (language consistency)
- LLM-Powered (AI analysis - placeholder)

**Key Classes:**
- `IntegrityAuditor` - Main auditor
- `AuditReport` - Audit results
- `AuditIssue` - Individual issues

---

### 10. Image Analysis (image_analysis/)

**Purpose:** Image analysis with LLM and OCR capabilities

**Files:**
- `image_analysis/analyzer.py` - Main analyzer
- `image_analysis/ocr_engine.py` - OCR engine

**Features:**
- LLM-powered image descriptions
- OCR text extraction (optional)
- Image classification
- Provider integration

**Key Classes:**
- `ImageAnalyzer` - Main analyzer
- `OCREngine` - OCR functionality
- `ImageAnalysisResult` - Analysis results

---

### 11. Dashboard Monitor (dashboard/)

**Purpose:** Real-time system monitoring and mission tracking

**Files:**
- `dashboard/monitor.py` - Monitor implementation
- `dashboard/models.py` - Dashboard models

**Features:**
- Agent status tracking
- Mission progress monitoring
- System metrics (uptime, memory, tasks)
- Component status monitoring

**Key Classes:**
- `DashboardMonitor` - Main monitor
- `SystemStatus` - System state
- `AgentStatus` - Agent state
- `MissionInfo` - Mission tracking

---

### 12. Boot Configurator (boot/)

**Purpose:** System boot configuration and validation

**Files:**
- `boot/configurator.py` - Boot configuration

**Features:**
- Configuration loading/saving
- Validation
- Default configuration setup

**Key Classes:**
- `BootConfigurator` - Boot manager

---

### 13. Recovery System (recovery/)

**Purpose:** Fault tolerance and crash recovery

**Files:**
- `recovery/system.py` - Recovery system

**Features:**
- Checkpoint creation
- State recovery
- Crash detection

**Key Classes:**
- `RecoverySystem` - Recovery manager

---

### 14. Web Interface (web/)

**Purpose:** REST API and WebSocket interface

**Files:**
- `web/server.py` - FastAPI server

**Features:**
- 25+ REST endpoints
- WebSocket real-time updates
- Static file serving
- CORS support

---

## System State Machine

```
┌──────────────────────────────────────────────────────────────┐
│                    SAGE OS State Machine                      │
└──────────────────────────────────────────────────────────────┘

    ┌─────────────────────────────────────────────────────────┐
    │ BOOT                                                    │
    │ - Initialize configuration                             │
    │ - Load boot settings                                   │
    │ - Validate configuration                               │
    └──────────────────┬──────────────────────────────────────┘
                       │
                       ▼
    ┌─────────────────────────────────────────────────────────┐
    │ KERNEL_READY                                            │
    │ - Initialize memory system                             │
    │ - Initialize event bus                                 │
    │ - Initialize agent router                              │
    │ - Initialize task dispatcher                           │
    │ - Initialize auditor                                   │
    │ - Initialize all PR components                         │
    └──────────────────┬──────────────────────────────────────┘
                       │
                       ▼
    ┌─────────────────────────────────────────────────────────┐
    │ COMMAND_MODE                                            │
    │ - Enter command execution mode                         │
    │ - Start CLI/Web interface                              │
    └──────────────────┬──────────────────────────────────────┘
                       │
                       ▼
    ┌─────────────────────────────────────────────────────────┐
    │ WAITING_FOR_USER_COMMAND                                │
    │ - Ready for user input                                 │
    │ - Listening on CLI/Web                                 │
    └──────────────────┬──────────────────────────────────────┘
                       │
                       │ (User enters command)
                       ▼
    ┌─────────────────────────────────────────────────────────┐
    │ COMMAND_EXECUTION                                       │
    │ - Parse command                                        │
    │ - Route to appropriate handler                         │
    │ - Execute command                                      │
    │ - Collect results                                      │
    └──────────────────┬──────────────────────────────────────┘
                       │
                       │ (Command complete)
                       ▼
    ┌─────────────────────────────────────────────────────────┐
    │ WAITING_FOR_USER_COMMAND (Loop)                         │
    │ - Return to waiting state                              │
    │ - System never terminates after KERNEL_READY           │
    └──────────────────────────────────────────────────────────┘
```

---

## Module Dependency Graph

```
┌─────────────────────────────────────────────────────────────┐
│                        Kernel                               │
│                    (core.py, state.py)                      │
└──────────────────┬──────────────────────────────────────────┘
                   │
        ┌──────────┼──────────┬──────────┬──────────┐
        │          │          │          │          │
        ▼          ▼          ▼          ▼          ▼
    ┌────────┐ ┌──────┐ ┌────────┐ ┌────────┐ ┌────────┐
    │ Memory │ │Events│ │Dispatch│ │ Agents │ │ Auditor│
    └────────┘ └──────┘ └────────┘ └────────┘ └────────┘
        │          │          │          │          │
        └──────────┼──────────┼──────────┼──────────┘
                   │
        ┌──────────┼──────────┬──────────┬──────────┐
        │          │          │          │          │
        ▼          ▼          ▼          ▼          ▼
    ┌────────┐ ┌──────┐ ┌────────┐ ┌────────┐ ┌────────┐
    │Provider│ │ Files│ │ Repo   │ │ Image  │ │Dashboard
    └────────┘ └──────┘ └────────┘ └────────┘ └────────┘
        │          │          │          │          │
        └──────────┼──────────┼──────────┼──────────┘
                   │
                   ▼
            ┌─────────────┐
            │ Web Server  │
            │ (FastAPI)   │
            └─────────────┘
```

---

## Integration Points

### 1. Kernel Boot Sequence

The kernel initializes all components in a specific order:

```python
async def _boot_phase(self):
    await self._init_config()              # Configuration
    await self._init_memory()              # Memory system
    await self._init_event_bus()           # Event communication
    await self._init_agent_router()        # Agent management
    await self._init_task_dispatcher()     # Task execution
    await self._init_auditor()             # Code auditing
    await self._init_provider_router()     # LLM providers (PR-009)
    await self._init_file_processor()      # File processing (PR-010)
    await self._init_repository_scanner()  # Repo analysis (PR-011)
    await self._init_image_analyzer()      # Image analysis (PR-013)
    await self._init_dashboard()           # Monitoring (PR-015)
```

### 2. API Layer Integration

All components expose REST endpoints via FastAPI:

```
Web Server (FastAPI)
├── Provider endpoints (PR-009)
├── File endpoints (PR-010)
├── Repository endpoints (PR-011)
├── Audit endpoints (PR-012)
├── Image endpoints (PR-013)
├── Multi-agent endpoints (PR-014)
├── Dashboard endpoints (PR-015)
└── Core endpoints (Kernel, Memory, Agents)
```

### 3. Event System Integration

Components communicate via the event bus:

```
Event Bus
├── Component A publishes event
├── Event Bus distributes to subscribers
├── Component B receives event
└── Component B processes event
```

### 4. Memory Integration

All state is persisted to SQLite:

```
Component State
    ↓
Memory Engine
    ↓
SQLite Database (~/.sage_os/memory.db)
    ↓
Automatic Checkpointing (5 min)
    ↓
Recovery System
```

---

## Conclusion

SAGE Runtime v4.5 is a comprehensive, modular system for AI-powered software engineering. All components are tightly integrated through the kernel, with clear separation of concerns and async-first design principles.

The architecture is **FROZEN** — no redesigns, no simplifications, exact preservation of the original SAGE OS v4.5 design.

**Next Document:** [02_API_REFERENCE.md](02_API_REFERENCE.md)
