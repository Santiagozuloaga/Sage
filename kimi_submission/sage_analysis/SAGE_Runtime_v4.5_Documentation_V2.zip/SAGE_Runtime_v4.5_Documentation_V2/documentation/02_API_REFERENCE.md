# SAGE Runtime v4.5 - API Reference

**Version:** 4.5  
**Base URL:** `http://127.0.0.1:8000`  
**Protocol:** REST + WebSocket  
**Status:** Production-Ready

---

## Table of Contents

1. [Authentication](#authentication)
2. [Core API Endpoints](#core-api-endpoints)
3. [Provider Layer (PR-009)](#provider-layer-pr-009)
4. [File Processing (PR-010)](#file-processing-pr-010)
5. [Repository Scanner (PR-011)](#repository-scanner-pr-011)
6. [Engineering Auditor (PR-012)](#engineering-auditor-pr-012)
7. [Image Analysis (PR-013)](#image-analysis-pr-013)
8. [Multi-Agent Execution (PR-014)](#multi-agent-execution-pr-014)
9. [Mission Dashboard (PR-015)](#mission-dashboard-pr-015)
10. [WebSocket Interface](#websocket-interface)
11. [Error Handling](#error-handling)
12. [Rate Limiting](#rate-limiting)

---

## Authentication

Currently, the API does **NOT require authentication**. All endpoints are publicly accessible on `127.0.0.1:8000`.

### Future Enhancement

Authentication will be added in a future PR with:
- API key validation
- JWT token support
- Role-based access control

---

## Core API Endpoints

### 1. Kernel Status

**GET** `/api/kernel/status`

Get current kernel status and system information.

**Response:**
```json
{
  "status": "WAITING_FOR_USER_COMMAND",
  "session_id": "abc12345",
  "uptime_seconds": 3600,
  "components_initialized": 14,
  "timestamp": "2026-07-05T13:00:00Z"
}
```

**Status Codes:**
- `200 OK` - Success
- `500 Internal Server Error` - Kernel error

---

### 2. Agent List

**GET** `/api/agents/list`

List all available agents.

**Response:**
```json
{
  "agents": [
    {
      "id": "sage_primary",
      "name": "SAGE",
      "type": "coordinator",
      "enabled": true,
      "capabilities": ["orchestration", "planning"]
    },
    {
      "id": "cascade_executor",
      "name": "Cascade",
      "type": "executor",
      "enabled": true,
      "capabilities": ["execution", "debugging"]
    }
  ],
  "total": 13
}
```

---

### 3. Memory Records

**GET** `/api/memory/records?limit=10&offset=0`

Retrieve engineering memory records.

**Query Parameters:**
- `limit` (int, default: 10) - Number of records
- `offset` (int, default: 0) - Pagination offset

**Response:**
```json
{
  "records": [
    {
      "id": "mem_001",
      "content": "Implemented feature X",
      "timestamp": "2026-07-05T12:00:00Z",
      "session_id": "abc12345",
      "metadata": {}
    }
  ],
  "total": 42
}
```

---

### 4. Execute Command

**POST** `/api/command/execute`

Execute a command in the kernel.

**Request Body:**
```json
{
  "command": "help",
  "context": {}
}
```

**Response:**
```json
{
  "success": true,
  "result": "Available commands: help, status, agents, exit",
  "execution_time_ms": 45
}
```

---

## Provider Layer (PR-009)

### 1. List Providers

**GET** `/api/providers`

Get status of all LLM providers.

**Response:**
```json
{
  "providers": [
    {
      "name": "gemini",
      "status": "healthy",
      "model": "gemini-pro",
      "last_check": "2026-07-05T13:00:00Z"
    },
    {
      "name": "grok",
      "status": "healthy",
      "model": "grok-1",
      "last_check": "2026-07-05T13:00:00Z"
    }
  ]
}
```

---

### 2. Chat with LLM

**POST** `/api/chat`

Send a message to an LLM provider.

**Request Body:**
```json
{
  "message": "Explain the kernel architecture",
  "provider": "gemini",
  "temperature": 0.7,
  "max_tokens": 1000
}
```

**Response:**
```json
{
  "success": true,
  "response": "The kernel is the central orchestrator...",
  "provider": "gemini",
  "tokens_used": 250,
  "execution_time_ms": 2500
}
```

**Provider Options:**
- `gemini` - Google Gemini (default)
- `grok` - xAI Grok
- `auto` - Automatic fallback

---

## File Processing (PR-010)

### 1. Upload and Process File

**POST** `/api/files/upload`

Upload and process a file.

**Request:**
- Method: `POST`
- Content-Type: `multipart/form-data`
- Body: File upload

**Response:**
```json
{
  "success": true,
  "file_id": "file_abc123",
  "filename": "document.pdf",
  "file_type": "pdf",
  "size_bytes": 102400,
  "content": "Extracted text from PDF...",
  "metadata": {
    "pages": 10,
    "language": "en"
  }
}
```

**Supported Formats:**
- PDF (`.pdf`)
- DOCX (`.docx`)
- Text & Markdown (`.txt`, `.md`)
- ZIP (`.zip`)
- Images (`.jpg`, `.png`, `.gif`)
- Code (`.py`, `.js`, `.java`, etc.)

**Parser Count:** 6 parsers supporting 7+ file formats

---

## Repository Scanner (PR-011)

### 1. Scan Repository

**POST** `/api/repository/scan`

Scan a repository for analysis.

**Request Body:**
```json
{
  "path": "/path/to/repo",
  "include_hidden": false,
  "max_depth": 10
}
```

**Response:**
```json
{
  "success": true,
  "repository": {
    "path": "/path/to/repo",
    "total_files": 256,
    "languages": {
      "python": 120,
      "javascript": 80,
      "json": 56
    },
    "functions": 450,
    "classes": 120,
    "imports": 890
  },
  "summary": "Repository analysis complete",
  "scan_time_ms": 5000
}
```

---

## Engineering Auditor (PR-012)

### 1. Run Audit

**POST** `/api/audit/run`

Run a comprehensive system audit.

**Request Body:**
```json
{
  "audit_types": ["code_quality", "security", "dependencies"],
  "include_llm": false
}
```

**Response:**
```json
{
  "success": true,
  "audit_id": "audit_001",
  "timestamp": "2026-07-05T13:00:00Z",
  "results": {
    "code_quality": {
      "issues": 5,
      "severity": "low"
    },
    "security": {
      "issues": 2,
      "severity": "medium"
    },
    "dependencies": {
      "issues": 0,
      "severity": "none"
    }
  },
  "total_issues": 7
}
```

---

### 2. Audit History

**GET** `/api/audit/history?limit=10`

Retrieve audit history.

**Query Parameters:**
- `limit` (int, default: 10) - Number of records

**Response:**
```json
{
  "audits": [
    {
      "audit_id": "audit_001",
      "timestamp": "2026-07-05T13:00:00Z",
      "total_issues": 7,
      "status": "completed"
    }
  ]
}
```

---

## Image Analysis (PR-013)

### 1. Analyze Image

**POST** `/api/image/analyze`

Analyze an uploaded image.

**Request:**
- Method: `POST`
- Content-Type: `multipart/form-data`
- Body: Image file

**Response:**
```json
{
  "success": true,
  "image_id": "img_abc123",
  "description": "A person working at a computer desk",
  "classification": "person",
  "confidence": 0.95,
  "ocr_text": "Optional: Extracted text from image",
  "metadata": {
    "width": 1920,
    "height": 1080,
    "format": "jpg"
  }
}
```

**Classifications:**
- `person` - Human subjects
- `animal` - Animals
- `nature` - Natural landscapes
- `building` - Architecture
- `technology` - Tech devices
- `vehicle` - Vehicles
- `food` - Food/meals
- `document` - Documents/text
- `chart` - Charts/diagrams
- `screenshot` - UI screenshots

---

## Multi-Agent Execution (PR-014)

### 1. Dispatch Multi-Agent Task

**POST** `/api/agents/multi`

Dispatch a task to multiple agents.

**Request Body:**
```json
{
  "task": "Analyze and optimize code",
  "agents": ["sage_primary", "cascade_executor"],
  "priority": "high",
  "timeout_seconds": 300
}
```

**Response:**
```json
{
  "success": true,
  "task_id": "task_abc123",
  "agents_assigned": 2,
  "status": "executing",
  "results": {
    "sage_primary": {
      "status": "completed",
      "result": "Analysis complete"
    },
    "cascade_executor": {
      "status": "executing",
      "progress": 0.65
    }
  }
}
```

---

## Mission Dashboard (PR-015)

### 1. Dashboard Status

**GET** `/api/dashboard/status`

Get current system and mission status.

**Response:**
```json
{
  "system": {
    "uptime_seconds": 3600,
    "memory_usage_mb": 256,
    "cpu_usage_percent": 12.5,
    "task_count": 42,
    "error_count": 0
  },
  "mission": {
    "current": "Code Review",
    "progress": 0.75,
    "started_at": "2026-07-05T12:00:00Z"
  },
  "agents": [
    {
      "id": "sage_primary",
      "status": "idle",
      "current_task": null
    }
  ]
}
```

---

### 2. Set Current Mission

**POST** `/api/dashboard/mission`

Set the current mission.

**Request Body:**
```json
{
  "mission": "Code Review",
  "description": "Review and optimize codebase"
}
```

**Response:**
```json
{
  "success": true,
  "mission": "Code Review",
  "started_at": "2026-07-05T13:00:00Z"
}
```

---

### 3. Update Agent Status

**POST** `/api/dashboard/agent`

Update agent status.

**Request Body:**
```json
{
  "agent_id": "sage_primary",
  "status": "executing",
  "current_task": "Analyzing repository"
}
```

**Response:**
```json
{
  "success": true,
  "agent_id": "sage_primary",
  "status": "executing"
}
```

---

## WebSocket Interface

### Connection

**WS** `/ws`

Connect to the WebSocket for real-time updates.

```javascript
const ws = new WebSocket('ws://127.0.0.1:8000/ws');

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Update:', data);
};
```

### Message Types

#### 1. System Status Update
```json
{
  "type": "system_status",
  "data": {
    "uptime_seconds": 3600,
    "memory_usage_mb": 256
  }
}
```

#### 2. Agent Status Update
```json
{
  "type": "agent_status",
  "data": {
    "agent_id": "sage_primary",
    "status": "executing"
  }
}
```

#### 3. Task Update
```json
{
  "type": "task_update",
  "data": {
    "task_id": "task_abc123",
    "status": "completed",
    "result": "..."
  }
}
```

#### 4. Event Notification
```json
{
  "type": "event",
  "data": {
    "event_type": "audit_complete",
    "timestamp": "2026-07-05T13:00:00Z"
  }
}
```

---

## Error Handling

### Error Response Format

All errors follow this format:

```json
{
  "success": false,
  "error": "Error description",
  "error_code": "INVALID_REQUEST",
  "details": {
    "field": "message"
  }
}
```

### Common Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `INVALID_REQUEST` | 400 | Invalid request parameters |
| `NOT_FOUND` | 404 | Resource not found |
| `UNAUTHORIZED` | 401 | Authentication required |
| `FORBIDDEN` | 403 | Access denied |
| `CONFLICT` | 409 | Resource conflict |
| `INTERNAL_ERROR` | 500 | Server error |
| `TIMEOUT` | 504 | Operation timeout |

### Example Error Response

```json
{
  "success": false,
  "error": "File not found",
  "error_code": "NOT_FOUND",
  "details": {
    "file_id": "file_abc123"
  }
}
```

---

## Rate Limiting

### Current Status

**Rate limiting is NOT currently implemented** but will be added in a future PR.

### Planned Implementation

- 100 requests per minute per IP
- 1000 requests per hour per IP
- Custom limits for authenticated users

### Headers

Future responses will include:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1625500800
```

---

## Endpoint Summary Table

| Method | Endpoint | PR | Status |
|--------|----------|----|----|
| GET | `/api/kernel/status` | Core | ✅ |
| GET | `/api/agents/list` | Core | ✅ |
| GET | `/api/memory/records` | Core | ✅ |
| POST | `/api/command/execute` | Core | ✅ |
| GET | `/api/providers` | PR-009 | ✅ |
| POST | `/api/chat` | PR-009 | ✅ |
| POST | `/api/files/upload` | PR-010 | ✅ |
| POST | `/api/repository/scan` | PR-011 | ✅ |
| POST | `/api/audit/run` | PR-012 | ✅ |
| GET | `/api/audit/history` | PR-012 | ✅ |
| POST | `/api/image/analyze` | PR-013 | ✅ |
| POST | `/api/agents/multi` | PR-014 | ✅ |
| GET | `/api/dashboard/status` | PR-015 | ✅ |
| POST | `/api/dashboard/mission` | PR-015 | ✅ |
| POST | `/api/dashboard/agent` | PR-015 | ✅ |
| WS | `/ws` | Core | ✅ |

---

## Next Document

[03_IMPLEMENTATION_GUIDE.md](03_IMPLEMENTATION_GUIDE.md)
