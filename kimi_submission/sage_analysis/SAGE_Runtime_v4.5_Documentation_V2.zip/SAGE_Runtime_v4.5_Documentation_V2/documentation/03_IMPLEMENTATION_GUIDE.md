# SAGE Runtime v4.5 - Implementation Guide

**Version:** 4.5  
**Audience:** Developers and AI Agents  
**Purpose:** Guide for understanding and extending the system

---

## Table of Contents

1. [Development Setup](#development-setup)
2. [Code Organization](#code-organization)
3. [Component Development](#component-development)
4. [PR Development Process](#pr-development-process)
5. [Testing & Validation](#testing--validation)
6. [Integration Patterns](#integration-patterns)
7. [Common Patterns](#common-patterns)
8. [Debugging](#debugging)

---

## Development Setup

### Prerequisites

- Python 3.11+
- pip or uv package manager
- Git
- 2GB+ disk space
- 512MB+ RAM

### Installation

```bash
# Clone repository
git clone <repository>
cd sage_runtime

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Verify installation
python -c "from kernel import SageKernel; print('✓ Installation successful')"
```

### Environment Setup

```bash
# Set required environment variables
export GEMINI_API_KEY="your-gemini-key"
export GROK_API_KEY="your-grok-key"

# Optional: Set custom config directory
export SAGE_OS_CONFIG_DIR="~/.sage_os"
```

### Running the System

```bash
# Start the runtime
python main.py

# Expected output:
# ======================================================================
# SAGE OS v4.5 - Local Runtime
# Architecture Status: FROZEN
# Engineering Status: ACTIVE
# ======================================================================
# 
# Web Interface: http://127.0.0.1:8000
# CLI Interface: Available (press Ctrl+C to exit)
```

---

## Code Organization

### Directory Structure

```
sage_runtime/
│
├── kernel/                    # Core kernel (2 files)
│   ├── core.py               # Main kernel class
│   └── state.py              # State machine
│
├── memory/                    # Memory system (2 files)
│   ├── engine.py             # SQLite persistence
│   └── models.py             # Data models
│
├── events/                    # Event bus (2 files)
│   ├── bus.py                # Event dispatcher
│   └── models.py             # Event models
│
├── dispatcher/                # Task execution (2 files)
│   ├── engine.py             # Task executor
│   └── models.py             # Task models
│
├── agents/                    # Agent routing (2 files)
│   ├── router.py             # Agent manager
│   └── models.py             # Agent models
│
├── auditor/                   # Code auditing (2 files)
│   ├── engine.py             # Audit engine
│   └── models.py             # Audit models
│
├── providers/                 # LLM providers (4 files)
│   ├── base_provider.py      # Abstract interface
│   ├── gemini_provider.py    # Gemini implementation
│   ├── grok_provider.py      # Grok implementation
│   └── provider_router.py    # Provider selection
│
├── file_processor/            # File processing (8 files)
│   ├── processor.py          # Main processor
│   └── parsers/
│       ├── pdf_parser.py
│       ├── docx_parser.py
│       ├── text_parser.py
│       ├── zip_parser.py
│       ├── image_parser.py
│       └── code_parser.py
│
├── repository_scanner/        # Repo analysis (4 files)
│   ├── scanner.py            # Main scanner
│   ├── language_detector.py  # Language detection
│   ├── ast_parser.py         # AST parsing
│   └── dependency_graph.py   # Dependency analysis
│
├── image_analysis/            # Image analysis (2 files)
│   ├── analyzer.py           # Main analyzer
│   └── ocr_engine.py         # OCR engine
│
├── dashboard/                 # Monitoring (2 files)
│   ├── monitor.py            # Monitor implementation
│   └── models.py             # Dashboard models
│
├── boot/                      # Boot config (1 file)
│   └── configurator.py       # Boot configurator
│
├── recovery/                  # Recovery (1 file)
│   └── system.py             # Recovery system
│
├── command_mode/              # Command execution (1 file)
│   └── executor.py           # Command executor
│
├── config/                    # Configuration (2 files)
│   ├── manager.py            # Config manager
│   └── provider_config.py    # Provider config
│
├── contracts/                 # Contracts (2 files)
│   ├── validator.py          # Contract validator
│   └── models.py             # Contract models
│
├── interface/                 # CLI interface (1 file)
│   └── cli.py                # CLI implementation
│
├── web/                       # Web server (1 file)
│   └── server.py             # FastAPI server
│
├── tests/                     # Validation tests (7 files)
│   ├── validate_pr009.py
│   ├── validate_pr010.py
│   ├── validate_pr011.py
│   ├── validate_pr012.py
│   ├── validate_pr013.py
│   ├── validate_pr014.py
│   └── validate_pr015.py
│
├── docs/                      # Documentation
│   ├── MIGRATION_REPORT.md
│   ├── REAL_IMPLEMENTATION_REPORT.md
│   └── RUNTIME_CAPABILITY_REPORT.md
│
├── main.py                    # Entry point
├── requirements.txt           # Dependencies
└── README.md                  # Project README
```

### Module Naming Conventions

- **Classes:** PascalCase (e.g., `SageKernel`, `MemoryEngine`)
- **Functions:** snake_case (e.g., `initialize_kernel`, `process_file`)
- **Constants:** UPPER_SNAKE_CASE (e.g., `MAX_RETRIES`, `DEFAULT_TIMEOUT`)
- **Private:** Leading underscore (e.g., `_internal_method`)

---

## Component Development

### 1. Creating a New Component

#### Step 1: Create Module Directory

```bash
mkdir -p sage_runtime/new_component
touch sage_runtime/new_component/__init__.py
```

#### Step 2: Define Data Models

```python
# new_component/models.py
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class ComponentState:
    """Component state representation."""
    id: str
    status: str
    created_at: datetime
    metadata: Optional[dict] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'metadata': self.metadata or {}
        }
```

#### Step 3: Implement Core Logic

```python
# new_component/engine.py
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class NewComponent:
    """Main component implementation."""
    
    def __init__(self):
        """Initialize component."""
        self._initialized = False
        logger.debug("[NEW_COMPONENT] Initialized")
    
    async def initialize(self):
        """Initialize component."""
        if self._initialized:
            return
        
        self._initialized = True
        logger.info("[NEW_COMPONENT] Initialization complete")
    
    async def shutdown(self):
        """Shutdown component."""
        self._initialized = False
        logger.info("[NEW_COMPONENT] Shutdown complete")
```

#### Step 4: Create __init__.py

```python
# new_component/__init__.py
from .engine import NewComponent
from .models import ComponentState

__all__ = ['NewComponent', 'ComponentState']
```

### 2. Integrating with Kernel

#### Step 1: Add Initialization Method

```python
# kernel/core.py - Add to SageKernel class

async def _init_new_component(self):
    """Initialize new component."""
    from new_component.engine import NewComponent
    
    component = NewComponent()
    await component.initialize()
    self._components['new_component'] = component
    logger.debug("[BOOT] New component initialized")
```

#### Step 2: Add to Boot Sequence

```python
# kernel/core.py - Modify _boot_phase method

async def _boot_phase(self):
    # ... existing initialization ...
    
    # Initialize new component
    await self._init_new_component()
    
    logger.info("[BOOT] All components initialized")
```

#### Step 3: Add Web Endpoint

```python
# web/server.py - Add to WebServer class

@self.app.get("/api/new-component/status")
async def new_component_status():
    """Get new component status."""
    try:
        component = self.kernel._components.get('new_component')
        if not component:
            return {"success": False, "error": "Component not initialized"}
        
        return {
            "success": True,
            "status": "operational"
        }
    except Exception as e:
        logger.error(f"[WEB] Error: {e}")
        return {"success": False, "error": str(e)}
```

---

## PR Development Process

### PR Structure

Each PR follows this structure:

```
PR-XXX: Feature Name
├── New module directory
├── Implementation files
├── Integration with kernel
├── Web API endpoints
├── Validation test script
└── Documentation update
```

### PR Development Steps

#### 1. Create PR Directory

```bash
mkdir -p sage_runtime/new_feature
```

#### 2. Implement Feature

```python
# sage_runtime/new_feature/engine.py
# sage_runtime/new_feature/models.py
# sage_runtime/new_feature/__init__.py
```

#### 3. Integrate with Kernel

```python
# Modify kernel/core.py to initialize new feature
async def _init_new_feature(self):
    # Implementation
```

#### 4. Add Web Endpoints

```python
# Modify web/server.py to add API endpoints
@self.app.post("/api/new-feature/execute")
async def execute_new_feature():
    # Implementation
```

#### 5. Create Validation Test

```python
# tests/validate_pr_xxx.py
import asyncio
import sys

def test_imports():
    """Test module imports."""
    try:
        from new_feature.engine import NewFeature
        from new_feature.models import FeatureModel
        print("  ✓ Imports successful")
        return True
    except ImportError as e:
        print(f"  ✗ Import failed: {e}")
        return False

def main():
    """Run validation tests."""
    print("="*70)
    print("PR-XXX Validation")
    print("="*70)
    
    if not test_imports():
        return 1
    
    print("\n✓ ALL TESTS PASSED - PR-XXX VALIDATED")
    return 0

if __name__ == "__main__":
    sys.exit(main())
```

#### 6. Run Validation

```bash
python tests/validate_pr_xxx.py
```

#### 7. Update Documentation

```bash
# Update SAGE_RUNTIME_STATUS.md with new PR info
# Update documentation/01_ARCHITECTURE_OVERVIEW.md
# Update documentation/02_API_REFERENCE.md
```

---

## Testing & Validation

### Validation Test Template

```python
# tests/validate_pr_xxx.py
import asyncio
import sys
import logging

logging.basicConfig(level=logging.INFO)

def test_imports():
    """Test module imports."""
    try:
        from new_feature.engine import NewFeature
        from new_feature.models import FeatureModel
        print("  ✓ Imports successful")
        return True
    except Exception as e:
        print(f"  ✗ Import failed: {e}")
        return False

def test_instantiation():
    """Test class instantiation."""
    try:
        from new_feature.engine import NewFeature
        feature = NewFeature()
        print("  ✓ Instantiation successful")
        return True
    except Exception as e:
        print(f"  ✗ Instantiation failed: {e}")
        return False

def test_kernel_integration():
    """Test kernel integration."""
    try:
        from kernel import SageKernel
        kernel = SageKernel()
        
        # Check if initialization method exists
        if hasattr(kernel, '_init_new_feature'):
            print("  ✓ Kernel integration successful")
            return True
        else:
            print("  ✗ Kernel integration method not found")
            return False
    except Exception as e:
        print(f"  ✗ Kernel integration failed: {e}")
        return False

def test_web_endpoints():
    """Test web API endpoints."""
    try:
        from web.server import WebServer
        from kernel import SageKernel
        
        kernel = SageKernel()
        server = WebServer(kernel)
        
        # Check if endpoints exist
        endpoints = [route.path for route in server.app.routes]
        if "/api/new-feature/execute" in endpoints:
            print("  ✓ Web endpoints registered")
            return True
        else:
            print("  ✗ Web endpoints not found")
            return False
    except Exception as e:
        print(f"  ✗ Web endpoint test failed: {e}")
        return False

def main():
    """Run all validation tests."""
    print("="*70)
    print("PR-XXX Validation")
    print("="*70)
    
    tests = [
        ("Imports", test_imports),
        ("Instantiation", test_instantiation),
        ("Kernel Integration", test_kernel_integration),
        ("Web Endpoints", test_web_endpoints),
    ]
    
    results = []
    for name, test_func in tests:
        print(f"\n[VALIDATION] Testing {name}...")
        results.append(test_func())
    
    print("\n" + "="*70)
    print("VALIDATION SUMMARY")
    print("="*70)
    
    for (name, _), result in zip(tests, results):
        status = "PASS" if result else "FAIL"
        print(f"{name}: {status}")
    
    if all(results):
        print("\n✓ ALL TESTS PASSED - PR-XXX VALIDATED")
        return 0
    else:
        print("\n✗ SOME TESTS FAILED - PR-XXX NOT VALIDATED")
        return 1

if __name__ == "__main__":
    sys.exit(main())
```

### Running Tests

```bash
# Run specific PR validation
python tests/validate_pr009.py

# Run all validations
for test in tests/validate_pr*.py; do
    echo "Running $test..."
    python "$test"
done
```

---

## Integration Patterns

### 1. Component Lifecycle

All components follow this lifecycle:

```python
class Component:
    def __init__(self):
        """Initialize (lightweight)."""
        self._initialized = False
    
    async def initialize(self):
        """Async initialization."""
        # Heavy lifting here
        self._initialized = True
    
    async def shutdown(self):
        """Cleanup on shutdown."""
        self._initialized = False
```

### 2. Logging Pattern

```python
import logging

logger = logging.getLogger(__name__)

# Use consistent format
logger.debug("[COMPONENT] Debug message")
logger.info("[COMPONENT] Info message")
logger.warning("[COMPONENT] Warning message")
logger.error("[COMPONENT] Error message")
```

### 3. Error Handling

```python
try:
    # Operation
    result = await operation()
except ValueError as e:
    logger.error(f"[COMPONENT] Invalid value: {e}")
    raise
except Exception as e:
    logger.error(f"[COMPONENT] Unexpected error: {e}", exc_info=True)
    raise
```

### 4. Async Pattern

```python
async def async_operation():
    """All I/O should be async."""
    try:
        result = await some_async_call()
        return result
    except Exception as e:
        logger.error(f"[COMPONENT] Error: {e}")
        raise
```

### 5. Web Endpoint Pattern

```python
@self.app.post("/api/component/action")
async def component_action(request: dict):
    """Web endpoint pattern."""
    try:
        component = self.kernel._components.get('component')
        if not component:
            return {"success": False, "error": "Component not initialized"}
        
        result = await component.perform_action(request)
        
        return {
            "success": True,
            "result": result
        }
    except Exception as e:
        logger.error(f"[WEB] Error: {e}")
        return {"success": False, "error": str(e)}
```

---

## Common Patterns

### 1. Data Model Pattern

```python
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class Record:
    """Data model."""
    id: str
    content: str
    created_at: datetime
    metadata: Optional[dict] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'content': self.content,
            'created_at': self.created_at.isoformat(),
            'metadata': self.metadata or {}
        }
    
    @classmethod
    def from_dict(cls, data: dict):
        """Create from dictionary."""
        return cls(
            id=data['id'],
            content=data['content'],
            created_at=datetime.fromisoformat(data['created_at']),
            metadata=data.get('metadata')
        )
```

### 2. Singleton Pattern

```python
class Singleton:
    """Singleton component."""
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
```

### 3. Factory Pattern

```python
class ComponentFactory:
    """Factory for creating components."""
    
    @staticmethod
    def create_component(component_type: str):
        """Create component by type."""
        if component_type == 'type_a':
            return ComponentA()
        elif component_type == 'type_b':
            return ComponentB()
        else:
            raise ValueError(f"Unknown type: {component_type}")
```

### 4. Observer Pattern

```python
class Observer:
    """Observer pattern."""
    
    def __init__(self):
        self._listeners = []
    
    def subscribe(self, listener):
        """Subscribe to events."""
        self._listeners.append(listener)
    
    def notify(self, event):
        """Notify all listeners."""
        for listener in self._listeners:
            listener(event)
```

---

## Debugging

### 1. Enable Debug Logging

```python
import logging

# Set to DEBUG level
logging.basicConfig(level=logging.DEBUG)

# Or for specific module
logger = logging.getLogger('sage_runtime.kernel')
logger.setLevel(logging.DEBUG)
```

### 2. Add Debug Breakpoints

```python
# Using pdb
import pdb; pdb.set_trace()

# Using breakpoint() (Python 3.7+)
breakpoint()
```

### 3. Print Debugging

```python
# Temporary debug output
print(f"DEBUG: {variable_name} = {variable_value}")
```

### 4. Async Debugging

```python
import asyncio

# Enable debug mode
asyncio.run(main(), debug=True)
```

### 5. Check Component Status

```python
# In Python REPL
from kernel import SageKernel
kernel = SageKernel()
print(kernel._components.keys())  # List all components
```

### 6. Review Logs

```bash
# Check configuration directory
ls -la ~/.sage_os/

# View memory database
sqlite3 ~/.sage_os/memory.db ".tables"
```

---

## Best Practices

### 1. Code Organization
- One class per file (unless closely related)
- Group related functions
- Keep files under 500 lines

### 2. Documentation
- Docstrings for all public methods
- Type hints for all parameters
- Comments for complex logic

### 3. Error Handling
- Use specific exceptions
- Log all errors
- Provide helpful error messages

### 4. Testing
- Test each component independently
- Create validation scripts for PRs
- Test integration with kernel

### 5. Performance
- Use async for I/O
- Cache expensive operations
- Monitor memory usage

### 6. Security
- Never hardcode credentials
- Use environment variables
- Validate all inputs
- Sanitize error messages

---

## Conclusion

This implementation guide provides the foundation for developing and extending SAGE Runtime v4.5. Follow the patterns and processes outlined here to ensure consistency and maintainability.

**Next Document:** [04_DEPLOYMENT_GUIDE.md](04_DEPLOYMENT_GUIDE.md)
