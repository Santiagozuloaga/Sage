"""
SAGE OS Task Dispatcher Engine

Command and task execution dispatcher with priority queuing.
"""

import asyncio
import logging
import uuid
import itertools
from datetime import datetime
from typing import Dict, Optional, Any, Callable, List
from collections import OrderedDict
import heapq

from .models import Task, TaskStatus, TaskPriority


logger = logging.getLogger(__name__)

# Maximum number of completed tasks to retain in memory.
# Older tasks are evicted automatically (LRU). This prevents
# unbounded memory growth in long-running kernels.
DEFAULT_COMPLETED_TASK_LIMIT = 500

# Maximum time (seconds) a task is allowed to execute before
# being marked as FAILED. Prevents deadlocks when providers hang.
TASK_EXECUTION_TIMEOUT = 60


class TaskDispatcher:
    """
    Task Dispatcher for command and task execution.
    
    Features:
    - Priority-based task queuing
    - Async task execution
    - Task status tracking
    - Result caching (bounded)
    - Error handling
    - Task cancellation
    - Multi-agent task execution
    - Execution timeout protection
    """

    def __init__(self, max_concurrent: int = 3):
        self._max_concurrent = max_concurrent
        self._task_queue: List[tuple] = []  # Priority queue
        self._running_tasks: Dict[str, Task] = {}
        # FIX D-2: Use OrderedDict with bounded size to prevent
        # unbounded memory growth. Oldest completed tasks are evicted
        # automatically when the limit is exceeded.
        self._completed_tasks: OrderedDict[str, Task] = OrderedDict()
        self._running = False
        self._processor_task: Optional[asyncio.Task] = None
        self._semaphore: Optional[asyncio.Semaphore] = None
        # Monotonic tie-breaker for the heap. Why: heapq falls back to
        # comparing the third tuple element (the Task) whenever the first
        # two are equal. Task is a plain @dataclass with no __lt__, so two
        # tasks dispatched with the same priority at the exact same
        # timestamp crashed with "'<' not supported between instances of
        # 'Task' and 'Task'" - reproduced by forcing two same-priority
        # dispatches with a mocked identical datetime.now(). An
        # ever-increasing counter guarantees no two heap entries ever tie,
        # so the Task objects are never compared, while still preserving
        # FIFO order within the same priority level.
        self._sequence = itertools.count()
        # Wired in post-construction via set_provider_router(), not passed
        # to __init__: the kernel initializes dispatcher before
        # provider_router in its optional-component boot sequence, so the
        # provider doesn't exist yet at TaskDispatcher construction time.
        self._provider_router = None

        # Event bus wiring point for event publishing during command execution
        self._event_bus = None

    def set_provider_router(self, provider_router) -> None:
        """
        Wire in the provider router after both components exist.

        Deliberately NOT wiring in agent_router here too. AgentRouter's
        registered roster is almost entirely external, human-operated dev
        tools (Jules, Cascade, Devin, Cursor, ...) that this process cannot
        invoke programmatically - only "Local Ollama"/"SAGE" map onto
        anything actually callable, which is provider_router itself. There
        is also no existing logic anywhere that classifies a raw command
        string into the AgentCapability enum route_to_agent() requires.
        Both of those are real design decisions, not bugs, so they are
        reported (see engineering changelog) instead of implemented here.
        """
        self._provider_router = provider_router

    def set_event_bus(self, event_bus) -> None:
        """
        Wire in the event bus after both components exist.

        Used to publish events during command execution for system-wide
        observability and component coordination.
        """
        self._event_bus = event_bus

    def set_agent_router(self, agent_router) -> None:
        """
        Wire in the agent router after both components exist.

        Used for load-aware routing in multi-agent execution (feature A-2 of Kimi).
        """
        self._agent_router = agent_router

    async def start(self):
        """Start the task dispatcher."""
        # FIX D-1: Idempotent start guard. Calling start() twice no longer
        # spawns multiple processor tasks that race on the same queue.
        if self._running and self._processor_task is not None:
            logger.debug("[DISPATCHER] Already running, ignoring start()")
            return
        self._running = True
        self._semaphore = asyncio.Semaphore(self._max_concurrent)
        self._processor_task = asyncio.create_task(self._process_tasks())
        logger.info("[DISPATCHER] Started")

    async def stop(self):
        """Stop the task dispatcher."""
        self._running = False
        if self._processor_task:
            self._processor_task.cancel()
            try:
                await self._processor_task
            except asyncio.CancelledError:
                pass
            self._processor_task = None
        # FIX D-3: Clear semaphore and task queue on stop to prevent
        # stale state on restart. Without this, a subsequent start()
        # would reuse the old semaphore reference and process leftover
        # tasks from the previous session.
        self._semaphore = None
        self._task_queue.clear()
        logger.info("[DISPATCHER] Stopped")

    async def dispatch(self, command: str, priority: TaskPriority = TaskPriority.MEDIUM) -> Any:
        """
        Dispatch a command for execution and wait for result.

        Returns the task result, not the Task object.
        """
        task = Task(
            task_id=str(uuid.uuid4())[:8],
            command=command,
            status=TaskStatus.PENDING,
            priority=priority,
            created_at=datetime.now()
        )

        # Add to priority queue (negative priority for max-heap behavior)
        priority_value = {
            TaskPriority.CRITICAL: 4,
            TaskPriority.HIGH: 3,
            TaskPriority.MEDIUM: 2,
            TaskPriority.LOW: 1
        }[priority]

        heapq.heappush(self._task_queue, (-priority_value, next(self._sequence), task))
        logger.info(f"[DISPATCHER] Dispatched task {task.task_id}: {command}")

        # Wait for task to complete
        while task.status == TaskStatus.PENDING or task.status == TaskStatus.RUNNING:
            await asyncio.sleep(0.1)
            # Check if task is in completed tasks
            if task.task_id in self._completed_tasks:
                task = self._completed_tasks[task.task_id]
                break

        # Return result or error
        if task.status == TaskStatus.COMPLETED:
            return task.result
        elif task.status == TaskStatus.FAILED:
            raise RuntimeError(f"Task failed: {task.error}")
        else:
            raise RuntimeError(f"Task in unexpected state: {task.status}")

    async def _process_tasks(self):
        """Process tasks from the queue."""
        while self._running:
            try:
                if self._task_queue:
                    _, _, task = heapq.heappop(self._task_queue)
                    asyncio.create_task(self._execute_task(task))
                else:
                    await asyncio.sleep(0.1)
            except asyncio.CancelledError:
                # Graceful shutdown on cancellation
                break
            except Exception as e:
                logger.error(f"[DISPATCHER] Error processing tasks: {e}")

    async def _execute_task(self, task: Task):
        """Execute a single task."""
        async with self._semaphore:
            task.status = TaskStatus.RUNNING
            task.started_at = datetime.now()
            self._running_tasks[task.task_id] = task

            logger.info(f"[DISPATCHER] Executing task {task.task_id}")

            try:
                # FIX D-4: Check for multi-agent tasks and execute accordingly.
                # Previously, multi-agent tasks were processed as regular tasks,
                # ignoring the agents list entirely.
                agents = task.metadata.get("agents") if task.metadata else None
                if agents and task.metadata.get("multi_agent"):
                    result = await self._execute_multi_agent(task.command, agents)
                else:
                    # FIX D-6: Wrap execution with timeout to prevent deadlocks
                    # when providers hang. Without this, a hung provider would
                    # hold a semaphore slot forever, eventually deadlocking the
                    # dispatcher after max_concurrent hung tasks.
                    result = await asyncio.wait_for(
                        self._execute_command(task.command),
                        timeout=TASK_EXECUTION_TIMEOUT
                    )

                task.status = TaskStatus.COMPLETED
                task.result = result
                task.completed_at = datetime.now()

                logger.info(f"[DISPATCHER] Task {task.task_id} completed")

            except asyncio.TimeoutError:
                task.status = TaskStatus.FAILED
                task.error = f"Task timed out after {TASK_EXECUTION_TIMEOUT}s"
                task.completed_at = datetime.now()
                logger.error(f"[DISPATCHER] Task {task.task_id} timed out")

            except Exception as e:
                task.status = TaskStatus.FAILED
                task.error = str(e)
                task.completed_at = datetime.now()

                logger.error(f"[DISPATCHER] Task {task.task_id} failed: {e}")

            finally:
                self._running_tasks.pop(task.task_id, None)
                # FIX D-2: Store completed task with LRU eviction.
                # Prevents unbounded memory growth in long-running kernels.
                self._completed_tasks[task.task_id] = task
                while len(self._completed_tasks) > DEFAULT_COMPLETED_TASK_LIMIT:
                    self._completed_tasks.popitem(last=False)

    async def _execute_multi_agent(self, command: str, agents: List[str]) -> Dict[str, Any]:
        """
        Execute a command across multiple agents in parallel.

        FIX D-4: Implements the multi-agent execution that was previously
        only a stub. Each agent gets the command executed independently,
        and results are aggregated.
        """
        logger.info(f"[DISPATCHER] Executing multi-agent task across {len(agents)} agents: {agents}")

        async def run_for_agent(agent_name: str) -> Dict[str, Any]:
            try:
                result = await self._execute_command(command)
                return {"agent": agent_name, "status": "success", "result": result}
            except Exception as e:
                return {"agent": agent_name, "status": "failed", "error": str(e)}

        # Execute across all agents in parallel
        results = await asyncio.gather(
            *[run_for_agent(agent) for agent in agents],
            return_exceptions=True
        )

        # Build aggregated result
        agent_results = {}
        for agent_name, result in zip(agents, results):
            if isinstance(result, Exception):
                agent_results[agent_name] = {"status": "failed", "error": str(result)}
            else:
                agent_results[agent_name] = result

        aggregated = await self.aggregate_results("multi_agent", agent_results)
        return aggregated

    async def dispatch_multi_agent(
        self,
        command: str,
        agents: list[str],
        priority: TaskPriority = TaskPriority.MEDIUM
    ) -> str:
        """
        Dispatch a task to multiple agents for parallel execution.
        
        Args:
            command: Command to execute
            agents: List of agent names to execute on
            priority: Task priority
            
        Returns:
            Task ID for the multi-agent task
        """
        task = Task(
            task_id=str(uuid.uuid4())[:8],
            command=command,
            status=TaskStatus.PENDING,
            priority=priority,
            created_at=datetime.now(),
            metadata={"agents": agents, "multi_agent": True}
        )
        
        # Add to priority queue
        priority_value = {
            TaskPriority.CRITICAL: 4,
            TaskPriority.HIGH: 3,
            TaskPriority.MEDIUM: 2,
            TaskPriority.LOW: 1
        }[priority]
        
        heapq.heappush(self._task_queue, (-priority_value, next(self._sequence), task))
        logger.info(f"[DISPATCHER] Dispatched multi-agent task {task.task_id} to {len(agents)} agents")
        
        return task.task_id

    async def delegate_to_agent(
        self,
        task_id: str,
        agent_name: str,
        subtask: str
    ) -> str:
        """
        Delegate a subtask to a specific agent.

        FIX D-5: Previously this method only generated a subtask ID stub
        without creating or dispatching a real task. Now it creates a
        proper Task, adds it to the priority queue, and returns a
        trackable task ID.

        Args:
            task_id: Parent task ID
            agent_name: Name of the agent
            subtask: Subtask command

        Returns:
            Subtask ID that can be looked up via get_task()
        """
        subtask_id = f"{task_id}_{agent_name}_{str(uuid.uuid4())[:4]}"

        # Create a real task for the subtask
        task = Task(
            task_id=subtask_id,
            command=subtask,
            status=TaskStatus.PENDING,
            priority=TaskPriority.HIGH,  # Subtasks are high priority
            created_at=datetime.now(),
            metadata={"parent_task": task_id, "agent": agent_name, "delegated": True}
        )

        # Add to priority queue (HIGH priority for subtasks)
        priority_value = 3  # HIGH
        heapq.heappush(self._task_queue, (-priority_value, next(self._sequence), task))

        logger.info(f"[DISPATCHER] Delegated subtask {subtask_id} to agent {agent_name}")

        return subtask_id

    async def aggregate_results(
        self,
        task_id: str,
        agent_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Aggregate results from multiple agents.
        
        Args:
            task_id: Parent task ID
            agent_results: Dict of agent_name -> result
            
        Returns:
            Aggregated result
        """
        aggregated = {
            "task_id": task_id,
            "agent_count": len(agent_results),
            "results": agent_results,
            "summary": self._summarize_results(agent_results)
        }
        
        logger.info(f"[DISPATCHER] Aggregated {len(agent_results)} agent results for task {task_id}")
        
        return aggregated

    def _summarize_results(self, agent_results: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a summary of agent results."""
        success_count = sum(1 for r in agent_results.values() if isinstance(r, dict) and r.get("success", False))
        
        return {
            "total_agents": len(agent_results),
            "successful": success_count,
            "failed": len(agent_results) - success_count,
            "success_rate": success_count / len(agent_results) if agent_results else 0
        }

    async def _execute_command(self, command: str) -> Any:
        """
        Execute a command.

        Real execution path: if a provider_router was wired in via
        set_provider_router(), the command is sent to it directly as a
        prompt via generate_text() (which already has its own
        online/auto-fallback logic between providers - see
        providers/provider_router.py). This is the minimal, unambiguous
        connection: provider_router is the only component that can
        actually produce a real response, and dispatcher's whole purpose
        is to execute commands, so *some* real call to it is required to
        move past the previous placeholder - it is not a new abstraction,
        just using the router's own existing public generate_text() method.

        What this does NOT do: assemble any system prompt, conversation
        history, or session context (no Context Manager exists anywhere in
        this codebase to build that from - confirmed by search, reported
        separately rather than invented here), and it does NOT route
        through agent_router (see set_provider_router's docstring for why).
        So this sends the raw command string as the entire prompt, nothing
        more. That's a real limitation, not hidden: results are marked with
        `"stub": False` here specifically so a caller can distinguish "ran
        for real, but with no context" from `"stub": True` ("didn't run at
        all"), rather than only having one bit of information.

        Falls back to the original placeholder behavior (stub: True) if no
        provider_router was wired in, so the dispatcher still works, in
        the same degraded sense as before, when used standalone.
        """
        if self._provider_router is not None:
            try:
                response = await self._provider_router.generate_text(command)
                result = {
                    "stub": False,
                    "output": response.content,
                    "provider": response.provider,
                    "model": response.model,
                    "latency_ms": response.latency_ms,
                }

                # Publish command execution event
                if self._event_bus:
                    from events.models import EventType
                    await self._event_bus.publish(
                        EventType.COMMAND_EXECUTED,
                        {"command": command, "provider": response.provider, "model": response.model},
                        "dispatcher"
                    )

                return result
            except Exception as e:
                logger.error(f"[DISPATCHER] Real execution failed for command {command!r}: {e}")

                # Publish command failed event
                if self._event_bus:
                    from events.models import EventType
                    await self._event_bus.publish(
                        EventType.COMMAND_FAILED,
                        {"command": command, "error": str(e)},
                        "dispatcher"
                    )

                raise

        logger.warning(
            f"[DISPATCHER] '_execute_command' running in stub mode (no provider_router "
            f"wired in) - task not actually routed to any provider or agent: {command!r}"
        )
        await asyncio.sleep(0.1)  # Simulate work
        return {"stub": True, "output": f"Executed: {command}"}

    def get_task(self, task_id: str) -> Optional[Task]:
        """Get a task by ID."""
        return self._completed_tasks.get(task_id) or self._running_tasks.get(task_id)

    def get_running_tasks(self) -> list[Task]:
        """Get all currently running tasks."""
        return list(self._running_tasks.values())

    def get_completed_tasks(self, limit: int = 100) -> list[Task]:
        """Get completed tasks."""
        tasks = list(self._completed_tasks.values())
        tasks.sort(key=lambda t: t.completed_at or t.created_at, reverse=True)
        return tasks[:limit]

    # FIX D-7: Implement task cancellation. TaskStatus.CANCELLED existed
    # in the enum but was never used — there was no way to cancel a task.
    def cancel_task(self, task_id: str) -> bool:
        """
        Cancel a pending or running task.

        Args:
            task_id: ID of the task to cancel

        Returns:
            True if the task was found and cancelled, False otherwise
        """
        # Check running tasks first
        task = self._running_tasks.get(task_id)
        if task:
            task.status = TaskStatus.CANCELLED
            task.completed_at = datetime.now()
            self._running_tasks.pop(task_id, None)
            self._completed_tasks[task_id] = task
            # Enforce limit
            while len(self._completed_tasks) > DEFAULT_COMPLETED_TASK_LIMIT:
                self._completed_tasks.popitem(last=False)
            logger.info(f"[DISPATCHER] Cancelled running task {task_id}")
            return True

        # Check pending tasks in queue
        for i, (_, _, queued_task) in enumerate(self._task_queue):
            if queued_task.task_id == task_id:
                queued_task.status = TaskStatus.CANCELLED
                queued_task.completed_at = datetime.now()
                # Remove from queue
                self._task_queue.pop(i)
                heapq.heapify(self._task_queue)  # Re-heapify after removal
                self._completed_tasks[task_id] = queued_task
                while len(self._completed_tasks) > DEFAULT_COMPLETED_TASK_LIMIT:
                    self._completed_tasks.popitem(last=False)
                logger.info(f"[DISPATCHER] Cancelled pending task {task_id}")
                return True

        return False

    async def shutdown(self):
        """Shutdown the dispatcher."""
        await self.stop()
        logger.info("[DISPATCHER] Shutdown complete")
