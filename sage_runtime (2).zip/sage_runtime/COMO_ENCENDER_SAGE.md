# CÓMO ENCENDER SAGE — Instrucciones Paso a Paso

Esto asume que no usaste una terminal antes. Cada paso te dice exactamente qué escribir.

---

## Paso 0: Descomprimir el zip

Sacá la carpeta `sage_runtime` de este zip a un lugar fácil de encontrar, por ejemplo `C:\Users\Admin\Desktop\sage_runtime`.

## Paso 1: Abrir una terminal (PowerShell) DENTRO de esa carpeta

La forma más fácil:
1. Abrí la carpeta `sage_runtime` en el Explorador de Windows.
2. Hacé clic en la barra de direcciones de arriba (donde dice la ruta de la carpeta), borrá lo que dice, escribí `powershell` y presioná Enter.
3. Se va a abrir una ventana negra/azul — esa es la terminal, ya parada dentro de la carpeta correcta. Esto es todo lo que vas a necesitar tocar con comandos.

## Paso 2: Instalar lo que falta (una sola vez)

En esa ventana, pegá esto y presioná Enter:

```
pip install -r requirements.txt
```

Va a tardar unos minutos y va a mostrar mucho texto — es normal, está descargando varias piezas (el servidor web, el conector con Ollama, etc.). Esperá a que vuelva a aparecer la línea para escribir (el cursor parpadeando), eso significa que terminó.

**Esto se hace UNA sola vez.** Las próximas veces que enciendas Sage, saltás directo al Paso 3.

## Paso 3: Confirmar que Ollama está corriendo

Abrí la app de Ollama si no está abierta (el ícono en la bandeja del sistema, abajo a la derecha). Si ya la tenías abierta, con eso alcanza.

## Paso 4: Encender Sage

En la misma ventana de PowerShell, escribí:

```
python main.py
```

y Enter. Vas a ver un montón de líneas de log, y al final algo así:

```
======================================================================
SAGE OS v4.5 Runtime Ready
======================================================================
Web Interface: http://127.0.0.1:8000
CLI Interface: Available (press Ctrl+C to exit)
======================================================================
```

**Dejá esta ventana abierta.** Si la cerrás, Sage se apaga. Podés minimizarla, no cerrarla.

## Paso 5: Ahí es donde realmente interactuás — en el navegador, no en la terminal

Abrí Chrome (o el navegador que uses) y andá a esta dirección, tal cual:

```
http://127.0.0.1:8000
```

Ahí vas a ver el panel de Sage. **Esto es lo que antes te confundía como "el HTML"** — es literalmente esa página. Buscá la consola de comandos (Command Console) y escribí algo simple para probar, por ejemplo `hola`.

Si Windows te pregunta si permitís acceso de red a Python (por el firewall), decile que sí — es normal, es el servidor local arrancando.

## Paso 6: Apagar Sage cuando termines

Volvé a la ventana de PowerShell (la que dejaste abierta) y presioná `Ctrl + C`. Esperá a que diga "Shutdown complete" antes de cerrarla.

---

## Qué esperar (para que no te asustes si algo de esto pasa)

- **Puede tardar en responder.** El hardware que tenés es limitado (sin GPU), así que una respuesta puede tardar bastante más que un chat normal. No es necesariamente que esté roto.
- **El panel de eventos y "Mission Control" probablemente aparezcan vacíos.** Ya está reportado, no es algo que rompiste vos.
- **Si escribís directo en la ventana negra de PowerShell, no va a pasar nada.** Esa ventana es solo para prender/apagar. Todo lo demás es en el navegador.

## Si algo falla

- **`pip` o `python` "no se reconoce como un comando"**: Python no está instalado o no está en el PATH. Avisame y lo vemos.
- **Error de conexión a Ollama**: abrí la app de Ollama y esperá unos segundos antes de reintentar `python main.py`.
- **La página de `http://127.0.0.1:8000` no carga**: revisá que la ventana de PowerShell siga abierta y diga "Runtime Ready" — si se cerró o dio error, mandame el mensaje de error tal cual salió.
