"""
Provider Router Error Handling Tests

Tests for ProviderRouter error handling improvements (error tracking, cooldown, auto-recovery).
"""

import sys
import asyncio
import time
from pathlib import Path

# Add sage_runtime to path
sys.path.insert(0, str(Path(__file__).parent.parent))


async def test_provider_router_error_tracking():
    """Test ProviderRouter error tracking and cooldown."""
    print("[TEST] Testing ProviderRouter error tracking...")
    
    from providers.provider_router import ProviderRouter
    
    router = ProviderRouter()
    
    # Test error recording
    router._record_error("test_provider")
    assert router._error_counts["test_provider"] == 1
    print("  ✓ Error recording works")
    
    # Test multiple errors
    router._record_error("test_provider")
    router._record_error("test_provider")
    assert router._error_counts["test_provider"] == 3
    print("  ✓ Multiple error tracking works")
    
    # Test provider disabling after threshold
    router._record_error("test_provider")  # 4th error, should disable
    assert "test_provider" in router._disabled_providers
    print("  ✓ Provider disabling after threshold works")
    
    # Test success recording resets error count
    router._record_success("test_provider")
    assert router._error_counts["test_provider"] == 0
    print("  ✓ Success recording resets error count")
    
    return True


async def test_provider_router_cooldown():
    """Test ProviderRouter cooldown and auto-recovery."""
    print("\n[TEST] Testing ProviderRouter cooldown...")
    
    from providers.provider_router import ProviderRouter
    
    router = ProviderRouter()
    
    # Override cooldown for testing
    router._cooldown_seconds = 1
    router._max_errors = 2
    
    # Disable a provider
    router._record_error("test_provider")
    router._record_error("test_provider")
    router._record_error("test_provider")  # Should disable
    
    assert "test_provider" in router._disabled_providers
    print("  ✓ Provider disabled")
    
    # Check it's excluded from available providers
    router._providers["test_provider"] = None  # Mock provider
    available = router.get_available_providers()
    assert "test_provider" not in available
    print("  ✓ Disabled provider excluded from available")
    
    # Wait for cooldown
    time.sleep(1.1)
    
    # Check auto-recovery
    available = router.get_available_providers()
    assert "test_provider" in available
    print("  ✓ Provider auto-recovered after cooldown")
    
    return True


async def test_provider_router_fallback():
    """Test ProviderRouter fallback logic."""
    print("\n[TEST] Testing ProviderRouter fallback...")
    
    from providers.provider_router import ProviderRouter
    from providers.base_provider import ProviderStatus
    
    router = ProviderRouter()
    
    # Mock providers
    class MockProvider:
        def __init__(self, name, status=ProviderStatus.ONLINE):
            self.provider_name = name
            self._status = status
            self._latency = 100
        
        @property
        def status(self):
            return self._status
        
        @property
        def last_latency_ms(self):
            return self._latency
    
    router._providers["provider1"] = MockProvider("provider1", ProviderStatus.ONLINE)
    router._providers["provider2"] = MockProvider("provider2", ProviderStatus.ONLINE)
    router._providers["provider3"] = MockProvider("provider3", ProviderStatus.ONLINE)
    
    # Disable provider1
    router._disabled_providers["provider1"] = time.time() + 100
    
    # Fallback should skip disabled provider
    fallback = router._get_fallback_provider("provider2")
    assert fallback is not None
    assert fallback.provider_name != "provider1"
    print("  ✓ Fallback skips disabled providers")
    
    return True


async def main():
    """Run all provider router tests."""
    print("="*70)
    print("Provider Router Error Handling Tests")
    print("="*70)
    
    tests = [
        ("Error Tracking", test_provider_router_error_tracking),
        ("Cooldown & Auto-Recovery", test_provider_router_cooldown),
        ("Fallback Logic", test_provider_router_fallback)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n✗ {test_name} raised exception: {e}")
            results.append((test_name, False))
    
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"{test_name}: {status}")
    
    all_passed = all(result for _, result in results)
    
    print("\n" + "="*70)
    if all_passed:
        print("✓ ALL TESTS PASSED")
        print("="*70)
        return 0
    else:
        print("✗ SOME TESTS FAILED")
        print("="*70)
        return 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
