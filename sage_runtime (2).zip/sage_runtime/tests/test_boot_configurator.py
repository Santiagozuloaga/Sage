"""
Boot Configurator Tests

Tests for BootConfigurator improvements (atomic writes, validation, locked keys).
"""

import sys
import asyncio
import tempfile
from pathlib import Path

# Add sage_runtime to path
sys.path.insert(0, str(Path(__file__).parent.parent))


async def test_boot_configurator():
    """Test BootConfigurator improvements."""
    print("[TEST] Testing BootConfigurator...")
    
    from boot.configurator import BootConfigurator
    
    with tempfile.TemporaryDirectory() as tmpdir:
        config_dir = Path(tmpdir)
        configurator = BootConfigurator(config_dir)
        
        # Test load/save
        await configurator.load()
        print("  ✓ Configuration loaded")
        
        # Test atomic save
        result = await configurator.save()
        assert result == True
        print("  ✓ Atomic save works")
        
        # Test locked keys
        result = configurator.set("version", "custom")
        assert result == False
        print("  ✓ Locked keys protected")
        
        # Test merge
        configurator.merge({"new_key": "new_value"})
        assert configurator.get("new_key") == "new_value"
        print("  ✓ Merge works")
        
        # Test reset to defaults
        configurator.set("boot_mode", "custom")
        await configurator.reset_to_defaults()
        assert configurator.get("boot_mode") == "normal"
        print("  ✓ Reset to defaults works")
        
        # Test get_all
        all_config = configurator.get_all()
        assert isinstance(all_config, dict)
        assert "version" in all_config
        print("  ✓ Get all works")
        
        # Test validation
        is_valid = await configurator.validate()
        assert is_valid == True
        print("  ✓ Validation works")
    
    return True


async def test_corrupted_config_recovery():
    """Test corrupted config recovery."""
    print("\n[TEST] Testing corrupted config recovery...")
    
    from boot.configurator import BootConfigurator
    import json
    
    with tempfile.TemporaryDirectory() as tmpdir:
        config_dir = Path(tmpdir)
        configurator = BootConfigurator(config_dir)
        
        # Create corrupted config file
        config_file = config_dir / "boot_config.json"
        with open(config_file, 'w') as f:
            f.write("{ invalid json")
        
        # Load should handle corrupted config
        await configurator.load()
        print("  ✓ Corrupted config handled")
        
        # Check that backup was created
        backup_file = config_dir / "boot_config.json.corrupted"
        assert backup_file.exists()
        print("  ✓ Corrupted config backed up")
        
        # Config should have defaults
        assert configurator.get("version") == "4.5"
        print("  ✓ Defaults loaded after corruption")
    
    return True


async def main():
    """Run all boot configurator tests."""
    print("="*70)
    print("Boot Configurator Tests")
    print("="*70)
    
    tests = [
        ("BootConfigurator", test_boot_configurator),
        ("Corrupted Config Recovery", test_corrupted_config_recovery)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n✗ {test_name} raised exception: {e}")
            results.append((test_name, False))
    
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"{test_name}: {status}")
    
    all_passed = all(result for _, result in results)
    
    print("\n" + "="*70)
    if all_passed:
        print("✓ ALL TESTS PASSED")
        print("="*70)
        return 0
    else:
        print("✗ SOME TESTS FAILED")
        print("="*70)
        return 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
