# SAGE_V2_ARCHITECTURE.md — Arquitectura de Evolución

**Autor:** GLM (Arquitecto de Evolución de SAGE)
**Fecha:** 2026-07-06
**Versión de diseño:** SAGE v2.0 (target: Q4 2026 / Q1 2027)
**Estado:** DISEÑO — no implementar
**Alcance:** visión arquitectónica, capas, dependencias, comunicación, APIs, puntos de extensión
**Restricciones respetadas:** no se modifica el código existente; todos los módulos viven en archivos nuevos; no se rehacen auditorías previas.

---

## 1. Visión

SAGE v1 (rama actual en fusión) es un **núcleo operativo monolítico** — 14 componentes-core administrados por un kernel central con FSM estricta, event bus pub-sub, dispatcher de tareas prioritarias, memoria SQLite, y una capa de providers LLM con fallback. La arquitectura está **FROZEN** por decisión del Arquitecto, lo que limita la evolución directa del core.

SAGE v2 debe ser un **sistema extensible por composición**, no por modificación. La premisa clave: **cualquier capacidad nueva debe poder añadirse sin tocar una sola línea del core FROZEN**. Esto se logra mediante:

1. **Capa de plugins** que consume eventos del bus existente y expone nuevos componentes vía registry lateral.
2. **Capa de servicios laterales** (sidecar) que operan en procesos separados y hablan con el core vía WebSocket/HTTP sin heredar su memoria ni su ciclo de vida.
3. **Capa de interfaces** (REST v2, SDK, dashboard web) que reemplaza gradualmente la interfaz actual sin reemplazar el core.
4. **Capa de observabilidad** que consume el event bus como suscriptor wildcard y produce métricas/trazas/logs sin acoplarse a componentes individuales.

El núcleo v1 permanece intacto. v2 lo envuelve.

---

## 2. Principios de Diseño

| # | Principio | Razón |
|---|---|---|
| 1 | **Composición sobre herencia** | No se subclassifica nada del core; se compone via eventos y registry. |
| 2 | **Event-sourced side-effects** | Toda acción de un módulo v2 se inicia como reacción a un evento del bus. |
| 3 | **Lateral registry** | Los módulos v2 se registran en un `ExtensionRegistry` propio, no en `kernel._components`. El core los ignora; v2 los orquesta. |
| 4 | **Process isolation para lo crítico** | Cost tracker, telemetry y backup corren en procesos separados — un bug en ellos no tumba el kernel. |
| 5 | **Convenzioni sobre configuración** | Los módulos v2 se auto-describen vía manifest; no requieren edits al config del core. |
| 6 | **Backward compatibility perpetua** | Cualquier módulo v2 puede desactivarse sin que el core deje de funcionar. |
| 7 | **Progressive disclosure** | v2 no rompe la API v1; añade endpoints `/api/v2/...` paralelos. |
| 8 | **Single source of truth por dominio** | Memory sigue siendo fuente de verdad de sesión; Knowledge Base es fuente de verdad de conocimiento durable; Audit Log es fuente de verdad de eventos de seguridad. |

---

## 3. Capas de la Arquitectura v2

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      CAPA 4 — OPERACIONES                                │
│  Telemetry · Audit Log · Backup · Cost Tracker · Performance Profiler    │
│  (procesos aislados, leen del bus y de filesystem)                       │
└─────────────────────────────────────────────────────────────────────────┘
                                  ▲
                                  │ subscribe (wildcard)
                                  │
┌─────────────────────────────────────────────────────────────────────────┐
│                      CAPA 3 — INTERFACES                                 │
│  REST API v2 · WebSocket Hub · SDK Python · SDK JS · Dashboard Web v2    │
│  Voice Interface · Visual Workflow Builder · Admin Panel                 │
│  (clientes del core; no comparten proceso salvo Dashboard Web v2)        │
└─────────────────────────────────────────────────────────────────────────┘
                                  ▲
                                  │ HTTP/WS / SDK calls
                                  │
┌─────────────────────────────────────────────────────────────────────────┐
│                      CAPA 2 — CAPACIDADES                                │
│  Knowledge Base · Skills System · Cache Layer · Rate Limiter             │
│  Search Engine · Notification System · Cron Scheduler · Profile System   │
│  (módulos Python en el mismo proceso del core, registry lateral)         │
└─────────────────────────────────────────────────────────────────────────┘
                                  ▲
                                  │ ExtensionRegistry + Event Bus
                                  │
┌─────────────────────────────────────────────────────────────────────────┐
│                      CAPA 1 — ADAPTADORES                                │
│  Plugin Runtime · Event Bridge · Lateral Component Registry              │
│  (puente entre v2 y el core FROZEN; único módulo que toca el bus)        │
└─────────────────────────────────────────────────────────────────────────┘
                                  ▲
                                  │ subscribe / publish / get_component
                                  │
┌─────────────────────────────────────────────────────────────────────────┐
│                      CAPA 0 — CORE FROZEN (v1)                           │
│  Kernel · Dispatcher · Memory · Event Bus · Recovery · Mission Control   │
│  Boot · Config · Providers · Agents · Auditor · Dashboard v1 · Web v1    │
│  (NO MODIFICAR — todo v2 lo rodea sin tocarlo)                           │
└─────────────────────────────────────────────────────────────────────────┘
```

### 2.1 Capa 0 — Core FROZEN (v1)

No se modifica. Incluye los 14 componentes existentes. Cualquier bug se fixea dentro de los handoffs ya acordados (Claude A + RE + Kimi + Cascade wiring).

### 2.2 Capa 1 — Adaptadores

Tres módulos puentes:

- **Plugin Runtime** — descubre, carga y supervisa plugins. Vive en `plugins/runtime.py` (nuevo). Es el único módulo v2 que obtiene referencias activas al `EventBus` y al `kernel.get_component()` del core — y solo las expone a plugins bajo contrato de solo-lectura.
- **Event Bridge** — puente unidireccional core→v2. Suscribe un wildcard handler al bus del core; transforma eventos v1 en eventos v2 (schema enriquecido); publica en el bus interno de v2. Vive en `extensions/event_bridge.py`.
- **Lateral Component Registry** — registro separado de `kernel._components`. Los módulos v2 se registran acá; el core nunca los ve, pero otros módulos v2 y las interfaces pueden descubrirlos. Vive en `extensions/registry.py`.

### 2.3 Capa 2 — Capacidades

Módulos funcionales nuevos que dan capacidades que el core no tiene:

- **Knowledge Base** — almacenamiento durable de conocimiento (no de sesión). Vectores + documentos.
- **Skills System** — capacidades modulares invocables por agentes (p.ej. "skill:web_search", "skill:code_review").
- **Cache Layer** — cache L1 (memoria) y L2 (SQLite) de respuestas de providers.
- **Rate Limiter** — protege providers y recursos de abuso.
- **Search Engine** — búsqueda full-text sobre memory + knowledge base.
- **Notification System** — notificaciones por canal (email, webhook, slack, desktop).
- **Cron Scheduler** — programación calendaria de tareas (complementa al priority dispatcher).
- **Profile System** — preferencias de usuario y sesión.

### 2.4 Capa 3 — Interfaces

- **REST API v2** — nuevo router FastAPI en `/api/v2/...`, mountable sobre el web server existente vía `app.include_router()` (no modifica código de server.py, solo se monta).
- **WebSocket Hub** — gateway de eventos en tiempo real hacia clientes externos. Cliente del Event Bridge.
- **SDK Python** — librería `sage_sdk` separada del runtime. Habla con REST v2.
- **SDK JavaScript** — librería para navegador/Node. Habla con REST v2 + WS Hub.
- **Dashboard Web v2** — SPA (React/Vue) separada del `web/static/` actual. Sirve en otro puerto.
- **Voice Interface** — servicio TTS/ASR que habla con REST v2.
- **Visual Workflow Builder** — editor drag-and-drop de pipelines de agentes.
- **Admin Panel** — interfaz de administración (usuarios, permisos, plugins).

### 2.5 Capa 4 — Operaciones

Procesos aislados (sidecars):

- **Telemetry** — métricas Prometheus, traces OpenTelemetry.
- **Audit Log** — log append-only de eventos de seguridad y admin.
- **Backup** — snapshots periódicos de memory.db + knowledge base.
- **Cost Tracker** — contabilidad de uso de API por provider.
- **Performance Profiler** — profiling continuo de handlers.

---

## 4. Dependencias entre capas

```
CAPA 4 ──→ lee eventos ──→ CAPA 1 (Event Bridge)
CAPA 4 ──→ lee filesystem ──→ CAPA 0 (memory.db)
CAPA 4 NO depende de CAPA 2 ni CAPA 3 (procesos aislados)

CAPA 3 ──→ REST v2 / WS Hub ──→ CAPA 1 (Plugin Runtime)
CAPA 3 ──→ SDK ──→ CAPA 0 (HTTP al web server v1 existente)
CAPA 3 NO depende directamente de CAPA 2 (la descubre via registry lateral)

CAPA 2 ──→ se registra en ──→ CAPA 1 (Lateral Registry)
CAPA 2 ──→ publica/consume ──→ CAPA 1 (Event Bridge)
CAPA 2 NO toca CAPA 0 directamente (excepto Knowledge Base, que lee memory.db en solo-lectura)

CAPA 1 ──→ subscribe wildcard ──→ CAPA 0 (Event Bus)
CAPA 1 ──→ kernel.get_component() ──→ CAPA 0 (read-only)
CAPA 1 NO modifica CAPA 0
```

**Regla de oro:** las dependencias apuntan siempre hacia abajo. Ninguna capa inferior conoce a las superiores. CAPA 0 no sabe que CAPA 1 existe.

---

## 5. Comunicación

### 5.1 Patrones de comunicación entre capas

| Origen → Destino | Patrón | Mecanismo |
|---|---|---|
| CAPA 0 → CAPA 1 | Event publish | `EventBus.publish()` → wildcard subscriber en Event Bridge |
| CAPA 1 → CAPA 2 | Event re-publish | Event Bridge publica en bus interno v2; CAPA 2 se suscribe |
| CAPA 2 ↔ CAPA 2 | Method call via registry | `lateral_registry.get('knowledge_base').query(...)` |
| CAPA 2 → CAPA 3 | HTTP push | Notification System llama a webhook externo |
| CAPA 3 → CAPA 1 | HTTP/WS | SDK y Dashboard v2 hablan con REST v2 / WS Hub |
| CAPA 1 → CAPA 0 (read) | `kernel.get_component()` | Solo Plugin Runtime, solo lectura |
| CAPA 4 → CAPA 0 (read) | Filesystem | Telemetry lee `~/.sage_os/memory.db` (read-only) |

### 5.2 Esquema de eventos v2

El Event Bridge transforma eventos v1 (`EventType.BOOT`, `COMMAND_EXECUTED`, etc.) en eventos v2 con schema enriquecido:

- `event_id` (uuid v4)
- `event_type_v1` (original)
- `event_type_v2` (canonical: `sage.kernel.boot`, `sage.command.executed`, etc.)
- `source` (componente emisor)
- `correlation_id` (preservado de v1)
- `timestamp` (ISO-8601 con microsegundos)
- `payload` (data original)
- `extension_metadata` (tags añadidos por plugins: `cost_usd`, `tokens_in`, `tokens_out`, etc.)

### 5.3 Comunicación CAPA 3 → CAPA 0

Las interfaces v2 NO hablan directamente con el kernel. Hablan con el **REST v2** o el **WS Hub**, que son los únicos puntos de contacto con el core. Esto permite:

- Versionar la API sin tocar el core.
- Reemplazar el core en el futuro (v3) sin tocar las interfaces.
- Cargar balancear si el core se distribuye.

---

## 6. APIs Públicas de v2

### 6.1 API REST v2

Prefijo: `/api/v2/`. Endpoints propuestos (no se implementan — solo se diseña):

| Endpoint | Método | Propósito |
|---|---|---|
| `/api/v2/plugins` | GET, POST | Listar e instalar plugins |
| `/api/v2/plugins/{id}` | GET, DELETE | Inspeccionar y desinstalar |
| `/api/v2/plugins/{id}/enable` | POST | Activar plugin |
| `/api/v2/plugins/{id}/disable` | POST | Desactivar plugin |
| `/api/v2/knowledge` | GET, POST, DELETE | Gestionar conocimiento |
| `/api/v2/knowledge/search` | POST | Búsqueda semántica |
| `/api/v2/skills` | GET, POST | Listar y registrar skills |
| `/api/v2/skills/{id}/invoke` | POST | Invocar skill |
| `/api/v2/cache` | GET, DELETE | Inspeccionar y limpiar cache |
| `/api/v2/notifications` | GET, POST | Listar y crear notificaciones |
| `/api/v2/notifications/channels` | GET, POST | Gestionar canales |
| `/api/v2/profiles` | GET, POST, PATCH | Gestionar perfiles |
| `/api/v2/cron` | GET, POST, DELETE | Programar tareas calendaria |
| `/api/v2/cron/{id}/run` | POST | Ejecutar tarea on-demand |
| `/api/v2/audit` | GET | Consultar log de auditoría |
| `/api/v2/telemetry/metrics` | GET | Métricas Prometheus |
| `/api/v2/telemetry/traces` | GET | Traces OpenTelemetry |
| `/api/v2/costs` | GET | Costos por provider / período |
| `/api/v2/backups` | GET, POST | Listar y crear backups |
| `/api/v2/backups/{id}/restore` | POST | Restaurar backup |
| `/api/v2/workflows` | GET, POST, PUT, DELETE | Gestionar workflows |
| `/api/v2/workflows/{id}/run` | POST | Ejecutar workflow |
| `/api/v2/admin/users` | GET, POST, DELETE | Gestionar usuarios |
| `/api/v2/admin/permissions` | GET, POST | Gestionar permisos |
| `/api/v2/search` | POST | Búsqueda global (memory + knowledge) |

### 6.2 WebSocket Hub

Endpoint: `/ws/v2`. Eventos que empuja a clientes conectados:

- `sage.event.published` — cualquier evento del bus, en formato v2
- `sage.plugin.loaded` / `sage.plugin.unloaded`
- `sage.skill.invoked` / `sage.skill.completed`
- `sage.notification.dispatched`
- `sage.cost.threshold_reached`
- `sage.audit.entry_written`

### 6.3 SDK Python (paquete `sage-sdk`)

Clases principales (diseño, no código):

- `SageClient` — cliente HTTP/WS con auth y retry.
- `SageEventStream` — iterador async de eventos del WS Hub.
- `SagePlugin` — clase base para escribir plugins en Python.
- `SageSkill` — clase base para escribir skills.
- `SageWorkflow` — builder fluido de workflows.

### 6.4 SDK JavaScript (paquete `@sage/sdk`)

Mirror del SDK Python para navegador y Node.

### 6.5 Plugin Manifest Format

Archivo `sage-plugin.toml` que todo plugin debe incluir:

- `name`, `version`, `author`, `license`
- `entrypoint` — clase Python que implementa `SagePlugin`
- `events_subscribed` — lista de tipos de evento v2 que recibe
- `events_published` — lista de tipos que publica
- `components_provided` — qué entradas añade al Lateral Registry
- `permissions` — qué acceso requiere (filesystem, network, core_read)
- `config_schema` — esquema JSON de su configuración

---

## 7. Puntos de Extensión

### 7.1 Puntos de extensión del core (ya existentes, no se modifican)

- **EventBus wildcard subscription** — cualquier componente puede suscribirse a todos los eventos. Es el punto de extensión principal.
- **`kernel.get_component(name)`** — acceso read-only a componentes registrados.
- **FastAPI `app.include_router()`** — permite montar routers adicionales sin tocar `web/server.py`.
- **`~/.sage_os/`** — directorio de configuración compartido; nuevos módulos pueden añadir subdirectorios.

### 7.2 Puntos de extensión nuevos (capa 1)

- **Lateral Component Registry** — registro separado. Cualquier módulo v2 puede registrar componentes aquí sin tocar `kernel._components`.
- **Plugin Discovery Hook** — el Plugin Runtime escanea `~/.sage_os/plugins/` en busca de directorios con `sage-plugin.toml`.
- **Event Bridge Channel** — el Event Bridge publica eventos v2 en un bus interno; los plugins se suscriben a este bus, no al del core.
- **Skill Invocation Hook** — el Skills System expone `invoke(skill_id, params)` que cualquier plugin puede llamar.

### 7.3 Puntos de extensión futuros (capa 2+)

- **Knowledge Base Providers** — un plugin puede registrar un nuevo proveedor de conocimiento (p.ej. "Notion", "Confluence").
- **Notification Channels** — un plugin puede registrar un canal nuevo ("Telegram", "Discord").
- **Search Indexers** — un plugin puede registrar un indexer para un tipo de contenido nuevo.
- **Workflow Nodes** — un plugin puede registrar tipos de nodo para el Visual Workflow Builder.
- **Audit Log Writers** — un plugin puede registrar un writer (p.ej. "Sentry", "CloudWatch").

---

## 8. Topología de Despliegue

### 8.1 Despliegue mínimo (single-node)

```
┌──────────────────────────────────────────┐
│  Proceso 1: SAGE Core (python main.py)   │
│  ├── Kernel + 14 componentes v1          │
│  ├── Plugin Runtime (capa 1)             │
│  ├── Capa 2 (8 módulos, mismo proceso)   │
│  └── REST v2 + WS Hub (capa 3, routers)  │
└──────────────────────────────────────────┘
            ▲
            │ HTTP/WS
            ▼
┌──────────────────────────────────────────┐
│  Proceso 2: Dashboard Web v2 (Node)      │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  Proceso 3: Telemetry (Python)           │  ← sidecar
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│  Proceso 4: Cost Tracker (Python)        │  ← sidecar
└──────────────────────────────────────────┘
```

### 8.2 Despliegue distribuido (futuro)

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Nodo Core A    │     │  Nodo Core B    │     │  Nodo Core C    │
│  (kernel + v1)  │     │  (kernel + v1)  │     │  (kernel + v1)  │
└────────┬────────┘     └────────┬────────┘     └────────┬────────┘
         │                       │                       │
         └───────────┬───────────┴───────────┬───────────┘
                     │                       │
                     ▼                       ▼
         ┌────────────────────┐  ┌────────────────────┐
         │  Gateway API v2    │  │  WS Hub distribuido│
         │  (Nginx + FastAPI) │  │  (Redis pub-sub)   │
         └────────────────────┘  └────────────────────┘
                     │
                     ▼
         ┌────────────────────┐
         │  Plugin Pool        │
         │  (K8s deployment)   │
         └────────────────────┘
```

---

## 9. Seguridad

### 9.1 Modelo de confianza

- **CAPA 0** — confianza total. Es el kernel.
- **CAPA 1** — confianza alta. Solo el Plugin Runtime puede obtener referencias directas al core.
- **CAPA 2** — confianza media. Se ejecuta en el mismo proceso pero solo puede hacer lo que su manifest declare.
- **CAPA 3** — confianza baja. Habla por HTTP/WS, sujeto a auth.
- **CAPA 4** — confianza nula. Procesos aislados, solo lectura.

### 9.2 Permisos de plugins

Cada plugin declara en su manifest:

- `core_read: true/false` — puede leer `kernel.get_component()`.
- `filesystem: [paths]` — a qué rutas puede acceder.
- `network: [hosts]` — a qué hosts puede conectarse.
- `subprocess: true/false` — puede spawn procesos.
- `env: [vars]` — qué variables de entorno puede leer.

El Plugin Runtime aplica estos permisos en runtime (sandboxing via `ast` para código Python; via cgroups/seccomp para plugins binarios).

### 9.3 Autenticación de interfaces

- REST v2 — API key + JWT.
- WS Hub — token de sesión.
- SDK — API key + secret.
- Admin Panel — MFA.

---

## 10. Observabilidad

### 10.1 Métricas (Telemetry)

Métricas expuestas en formato Prometheus:

- `sage_commands_total{status}` — contador por status.
- `sage_command_duration_seconds` — histograma.
- `sage_provider_calls_total{provider,status}` — uso de providers.
- `sage_provider_cost_usd_total{provider}` — costo acumulado.
- `sage_memory_records_total` — Gauge.
- `sage_event_bus_handlers_active` — Gauge.
- `sage_plugin_load_seconds{plugin}` — tiempo de carga.
- `sage_dispatcher_queue_depth` — Gauge.

### 10.2 Trazas (Telemetry)

OpenTelemetry traces para cada comando:

```
command_execution (root span)
├── dispatcher_dispatch
├── task_execute
│   ├── provider_call (child)
│   │   ├── provider_health_check
│   │   └── provider_generate_text
│   └── skill_invocation (si aplica)
└── memory_save
```

### 10.3 Logs estructurados

JSON logs con campos:

- `timestamp`, `level`, `logger`, `message`
- `correlation_id`, `session_id`, `command_id`
- `component`, `subsystem`
- `event_type` (si el log es reacción a un evento)

---

## 11. Migración de v1 a v2

### 11.1 Estrategia

- **Coexistencia:** v1 y v2 corren en paralelo durante toda la transición. Los endpoints v1 (`/api/...`) permanecen; los v2 (`/api/v2/...`) se añaden.
- **Feature flags:** cada módulo v2 se activa vía `boot_config.json` (sin tocar el código del core).
- **Deprecación gradual:** los endpoints v1 se marcan como deprecated solo cuando el módulo v2 equivalente está estable.
- **Removal en v3:** los endpoints v1 se eliminan recién en v3.

### 11.2 Compatibilidad con datos

- `memory.db` de v1 sigue siendo usado por el core. v2 no lo modifica.
- Knowledge Base usa su propia DB (`~/.sage_os/knowledge.db`).
- Audit Log usa su propio archivo (`~/.sage_os/audit.log`).
- Telemetry usa su propio storage (Prometheus / SQLite local).

---

## 12. Riesgos Arquitectónicos

| Riesgo | Probabilidad | Impacto | Mitigación |
|---|---|---|---|
| El Event Bridge introduce latencia en el bus | Media | Bajo | El bridge es fire-and-forget; los handlers v2 corren async. |
| Un plugin malicioso corrompe el core | Media | Crítico | Sandboxing via manifest + proceso aislado para plugins no confiables. |
| La capa 2 crece sin control y se vuelve un segundo core | Alta | Medio | Límite: máximo 16 módulos capa 2; cada uno debe justificarse contra un caso de uso real. |
| Las interfaces v2 se vuelven incompatibles con v1 | Baja | Alto | Contract testing automático en CI. |
| El Performance Profiler introduce overhead | Media | Bajo | Profiler es opt-in por sesión, no siempre activo. |
| El Knowledge Base duplica datos del Memory | Alta | Bajo | KB se diseñó para conocimiento durable; Memory para sesión. Contracts distintos. |
| La distribución (8.2) requiere reescribir el kernel | Baja | Crítico | No se distribuye el kernel; se distribuyen los sidecars y el gateway. |

---

## 13. Roadmap resumido

(Ver detalle en `ROADMAP_V2.md`)

| Fase | Duración estimada | Módulos |
|---|---|---|
| Fase 1 — Cimientos | 4-6 semanas | Plugin Runtime, Event Bridge, Lateral Registry |
| Fase 2 — Capacidades base | 6-8 semanas | Knowledge Base, Skills, Cache, Rate Limiter |
| Fase 3 — Interfaces | 6-8 semanas | REST v2, WS Hub, SDK Python |
| Fase 4 — Observabilidad | 4-6 semanas | Telemetry, Audit Log, Cost Tracker |
| Fase 5 — Experiencia | 8-12 semanas | Dashboard v2, Workflow Builder, Voice Interface |
| Fase 6 — Operaciones | 4-6 semanas | Backup, Performance Profiler, Admin Panel |
| Fase 7 — Distribución | 12+ semanas | Multi-node, gateway distribuido |

**Total estimado:** 44-52 semanas (11-13 meses) para v2 completo. La meta realista es entregar Fases 1-4 (~20 semanas) como v2.0, Fases 5-6 como v2.1, y Fase 7 como v3.0.

---

## 14. Conclusiones

SAGE v2 es viable **sin tocar el core FROZEN**. La clave es la **Capa 1 de Adaptadores**: es el único punto donde v2 contacta a v1, y lo hace via los puntos de extensión existentes (EventBus wildcard + `kernel.get_component()` read-only). Todo lo demás es composición lateral.

La arquitectura propuesta:

- **Respeta** el mandato de no modificar el core.
- **Permite** evolución incremental (cada capa se añade sin romper las anteriores).
- **Aísla** fallos (sidecars para lo crítico).
- **Escala** hacia distribución sin reescritura.
- **Mantiene** compatibilidad con v1 durante toda la transición.

Los entregables siguientes detallan módulos (`NEW_MODULES_PROPOSAL.md`), visión de plugins (`PLUGIN_SYSTEM_VISION.md`), roadmap (`ROADMAP_V2.md`) y RFCs individuales (`RFC_FUTURE_MODULES.md`).

— GLM, Arquitecto de Evolución de SAGE
