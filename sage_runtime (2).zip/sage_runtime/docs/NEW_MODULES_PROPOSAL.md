# NEW_MODULES_PROPOSAL.md — Propuesta de Módulos Nuevos para SAGE v2

**Autor:** GLM (Arquitecto de Evolución de SAGE)
**Fecha:** 2026-07-06
**Estado:** PROPUESTA — no implementar
**Alcance:** 12 módulos nuevos, todos en archivos nuevos, ninguno modifica el core
**Documentos relacionados:** `SAGE_V2_ARCHITECTURE.md`, `PLUGIN_SYSTEM_VISION.md`, `RFC_FUTURE_MODULES.md`, `ROADMAP_V2.md`

---

## Convención de formato

Cada propuesta sigue este template:

```
### M## — Nombre del Módulo
- Problema que resuelve
- Beneficio
- Nivel de prioridad: Alta / Media / Baja
- Dependencias (módulos v2 internos + módulos core v1 que consume read-only)
- Riesgo (qué podría romper)
- Archivos nuevos que crearía (paths bajo ~/.sage_os/ o bajo el repo)
- Integración con el núcleo (cómo habla con el core sin modificarlo)
- Mini-RFC (referencia al RFC completo en RFC_FUTURE_MODULES.md)
```

---

## Resumen ejecutivo

Se proponen **12 módulos nuevos**, organizados por capa:

| ID | Módulo | Capa | Prioridad |
|----|--------|------|-----------|
| M01 | Plugin Runtime | 1 | Alta |
| M02 | Event Bridge | 1 | Alta |
| M03 | Lateral Component Registry | 1 | Alta |
| M04 | Knowledge Base | 2 | Alta |
| M05 | Skills System | 2 | Alta |
| M06 | Cache Layer | 2 | Media |
| M07 | Rate Limiter | 2 | Media |
| M08 | Notification System | 2 | Media |
| M09 | REST API v2 + WS Hub | 3 | Alta |
| M10 | Telemetry & Audit | 4 | Media |
| M11 | Cost Tracker | 4 | Media |
| M12 | Backup System | 4 | Baja |

**Adicionales mencionados pero no detallados** (prioridad Baja, fuera del alcance v2.0): Voice Interface, Visual Workflow Builder, Admin Panel, Multi-User, Distributed Agents, Search Engine, Cron Scheduler, Profile System, SDK JavaScript, Performance Profiler. Se listan en `RFC_FUTURE_MODULES.md` como RFCs ligeros para v2.1+.

---

## M01 — Plugin Runtime

**Problema que resuelve:** hoy, cualquier capacidad nueva requiere modificar archivos del core (kernel, dispatcher, providers, etc.), lo que choca con la regla "FROZEN". No existe un mecanismo estándar para añadir funcionalidad sin tocar el código existente.

**Beneficio:** permite a terceros (y a los propios agentes) extender SAGE sin tocar el core. Habilita un ecosistema de plugins. Unifica el patrón de extensión (hoy cada módulo nuevo inventaría el suyo).

**Nivel de prioridad:** Alta

**Dependencias:**
- v2 internos: ninguno (es fundación)
- v1 core read-only: `EventBus` (para suscripción wildcard), `kernel.get_component()` (para exponer a plugins bajo contrato)
- Externos: `tomli` (parseo de manifest TOML), `importlib` (carga dinámica)

**Riesgo:**
- Si un plugin crashea en su handler, el Event Bridge debe aislar el fallo para no contaminar al resto. Mitigación: cada plugin se ejecuta en un task async con try/except; los errores van al DLQ del bus.
- Si un plugin pide `core_read: true` y el Plugin Runtime se lo concede sin validación, el plugin puede leer credenciales en `kernel._components['config']`. Mitigación: lista blanca explícita de componentes accesibles.
- Conflictos de versión entre plugins que requieren la misma skill. Mitigación: resolver por `manifest.requires` con semver.

**Archivos nuevos que crearía:**
- `plugins/__init__.py`
- `plugins/runtime.py` — orquestador (load, enable, disable, unload)
- `plugins/manifest.py` — parser y validador de `sage-plugin.toml`
- `plugins/sandbox.py` — aplicación de permisos en runtime
- `plugins/loader.py` — descubrimiento en `~/.sage_os/plugins/`
- `plugins/contracts.py` — clases base `SagePlugin`, `SageSkill`, `SageWorkflow`
- `plugins/exceptions.py` — `PluginLoadError`, `PluginPermissionDenied`, `PluginManifestInvalid`
- `~/.sage_os/plugins/` — directorio de instalación
- `~/.sage_os/plugins/.installed.json` — índice de plugins instalados

**Integración con el núcleo sin modificarlo:**
1. El Plugin Runtime se inicializa después del boot del kernel, leyendo `~/.sage_os/plugins/.installed.json`.
2. Para cada plugin manifiestado, se suscribe al `EventBus` del core (vía wildcard o por tipo específico declarado en el manifest).
3. Para plugins con `core_read: true`, obtiene referencias via `kernel.get_component(name)` y las inyecta en el plugin bajo proxy read-only.
4. NO se registra en `kernel._components` — se registra en el Lateral Component Registry (M03).
5. Los plugins publican eventos v2 via el Event Bridge (M02), no directamente en el bus del core.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-001.

---

## M02 — Event Bridge

**Problema que resuelve:** el `EventBus` del core es v1-centric (tipos enum cerrados, sin schema estricto, sin correlation ID enriquecido). Los módulos v2 necesitan un bus con schema canónico, eventos tipados, y soporte para cross-correlation.

**Beneficio:** unifica el formato de eventos entre v1 y v2; permite que plugins y sidecars consuman eventos sin conocer el enum interno del core; habilita tracing distribuido vía correlation IDs.

**Nivel de prioridad:** Alta

**Dependencias:**
- v2 internos: M01 (Plugin Runtime — para entregar eventos a plugins)
- v1 core read-only: `EventBus.subscribe_wildcard()` (único subscriber)
- Externos: `pydantic` (validación de schema)

**Riesgo:**
- Latencia añadida: cada evento v1 pasa por el bridge antes de llegar a v2. Mitigación: el bridge es fire-and-forget async; los handlers v2 corren en su propio task.
- Si el bridge crashea, los plugins pierden eventos. Mitigación: el bridge tiene retry + DLQ propio; si cae, los eventos v1 siguen llegando al history del bus del core.
- Duplicación: si un plugin también se suscribe directamente al bus del core (no debería, pero podría), recibe el evento dos veces. Mitigación: el Plugin Runtime bloquea el acceso directo al bus del core; solo el bridge tiene la referencia.

**Archivos nuevos:**
- `extensions/__init__.py`
- `extensions/event_bridge.py` — suscriptor wildcard + transformador v1→v2 + publicador interno
- `extensions/event_schemas.py` — modelos pydantic para eventos v2
- `extensions/internal_bus.py` — bus interno v2 (pub-sub, similar al del core pero con schema)

**Integración con el núcleo:**
1. En el boot del Plugin Runtime, se suscribe un wildcard handler al `EventBus` del core.
2. El handler transforma el `Event` v1 en un `SageEventV2` (pydantic) y lo publica en el `internal_bus`.
3. Plugins y módulos v2 se suscriben al `internal_bus`, no al del core.
4. El bridge nunca publica en el bus del core — es unidireccional core→v2.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-002.

---

## M03 — Lateral Component Registry

**Problema que resuelve:** el `kernel._components` es el registry del core, pero los módulos v2 no deberían registrarse ahí (contaminarían el core y romperían su shutdown loop). Sin un registry separado, los módulos v2 no pueden descubrirse entre sí.

**Beneficio:** permite que módulos v2 se encuentren sin pasar por el core; Mantiene limpio el `kernel._components`; habilita lookups type-safe via interfaces declaradas.

**Nivel de prioridad:** Alta

**Dependencias:**
- v2 internos: M01 (Plugin Runtime)
- v1 core: ninguno (totalmente lateral)
- Externos: ninguno

**Riesgo:**
- Si dos módulos registran el mismo nombre, conflicto. Mitigación: nombres jerárquicos (`knowledge_base`, `cache.l1`, `cache.l2`).
- Si un módulo se desactiva pero otros dependen de él, fallo en cascada. Mitigación: dependencias declaradas en el manifest; el registry rechaza desactivar un módulo con dependientes vivos.

**Archivos nuevos:**
- `extensions/registry.py` — `LateralRegistry` class
- `extensions/interfaces.py` — interfaces abstractas (`IKnowledgeBase`, `ICache`, `ISkill`, etc.) que los módulos deben implementar

**Integración con el núcleo:**
- Ninguna directa. El registry es completamente lateral.
- Los módulos v2 lo usan para descubrirse entre sí.
- El Plugin Runtime expone el registry a los plugins via `SagePlugin.registry`.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-003.

---

## M04 — Knowledge Base

**Problema que resuelve:** `memory/engine.py` es para estado de sesión (registros de ingeniería, PRs, sesiones). No sirve para conocimiento durable semántico (documentos, FAQs, código de referencia). Cada agente hoy reinicia sin contexto acumulado.

**Beneficio:** permite que SAGE aprenda de sesiones anteriores y tenga base de conocimiento compartida entre agentes. Habilita RAG (Retrieval-Augmented Generation) en las llamadas a providers.

**Nivel de prioridad:** Alta

**Dependencias:**
- v2 internos: M01, M02, M03
- v1 core read-only: `memory.engine` (para correlacionar knowledge con session_id)
- Externos: `chromadb` o `qdrant-client` (vector store), `sentence-transformers` (embeddings), `sqlite3` (metadata)

**Riesgo:**
- Tamaño: la KB puede crecer sin bound. Mitigación: política de retención + TTL por documento.
- Costo de embeddings: si se usa un modelo online, cada inserción cuesta. Mitigación: usar `sentence-transformers` local por defecto.
- Contaminación: si un agente inserta conocimiento erróneo, contaminará futuras respuestas. Mitigación: scoring de confianza + revisión humana opcional.

**Archivos nuevos:**
- `knowledge_base/__init__.py`
- `knowledge_base/engine.py` — `KnowledgeBase` class (CRUD + search)
- `knowledge_base/embeddings.py` — wrapper sobre sentence-transformers
- `knowledge_base/vector_store.py` — wrapper sobre ChromaDB/Qdrant
- `knowledge_base/ingestor.py` — pipelines de ingestión (text, markdown, code, pdf)
- `knowledge_base/retriever.py` — retrieval con filtros y reranking
- `knowledge_base/models.py` — `KnowledgeDocument`, `KnowledgeChunk`, `KnowledgeQuery`
- `~/.sage_os/knowledge_db/` — directorio de la vector store
- `~/.sage_os/knowledge_meta.db` — SQLite para metadata

**Integración con el núcleo:**
- Lee `session_id` de los eventos v1 (`COMMAND_EXECUTED`) para asociar conocimiento a la sesión que lo originó.
- NO intercepta llamadas a providers — eso requeriría modificar el dispatcher. En su lugar, expone `knowledge_base.retriever.search(query)` que el Context Manager (cuando exista, pendiente de Cascade) puede llamar.
- Publica eventos v2: `sage.knowledge.document_added`, `sage.knowledge.search_performed`.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-004.

---

## M05 — Skills System

**Problema que resuelve:** hoy las "capacidades" de los agentes están hardcodeadas en `agents/models.py` como un enum (`AgentCapability.CODE_GENERATION`, etc.). No hay forma de añadir capacidades nuevas (p.ej. "web_search", "code_review", "sql_query") sin modificar el enum y los agentes.

**Beneficio:** convierte las capacidades en módulos plugables. Un agente puede tener N skills; cada skill es un módulo Python con un contrato claro. Habilita un ecosistema de skills reutilizables.

**Nivel de prioridad:** Alta

**Dependencias:**
- v2 internos: M01, M02, M03, M04 (para skills que hacen RAG)
- v1 core read-only: `agents.router` (para que un agente pueda declarar qué skills tiene)
- Externos: ninguno (solo stdlib)

**Riesgo:**
- Una skill mal implementada puede colgar al agente. Mitigación: timeout por skill invocation (similar a D-6 de Kimi en dispatcher).
- Conflicto de nombres: dos skills con el mismo ID. Mitigación: namespacing por plugin (`plugin_name.skill_name`).
- Permisos: una skill de "filesystem.write" podría ser peligrosa. Mitigación: la skill declara permisos en su manifest; el Skills System los aplica.

**Archivos nuevos:**
- `skills/__init__.py`
- `skills/registry.py` — `SkillRegistry` (registro lateral, no en kernel)
- `skills/base.py` — `Skill` abstract class con `invoke(params) -> result`
- `skills/context.py` — `SkillContext` (recursos disponibles: knowledge_base, memory read, etc.)
- `skills/builtin/` — skills de referencia:
  - `skills/builtin/web_search.py`
  - `skills/builtin/code_review.py`
  - `skills/builtin/sql_query.py`
  - `skills/builtin/file_read.py`
- `skills/exceptions.py` — `SkillNotFoundError`, `SkillTimeoutError`, `SkillPermissionDenied`

**Integración con el núcleo:**
- NO modifica `agents/models.py` ni `agents/router.py`. El enum `AgentCapability` se mantiene como está.
- Las skills v2 son un concepto paralelo. Un agente v1 declara capacidades del enum; un agente v2 (cuando exista) declarará skills por ID.
- Puente: el Plugin Runtime expone `kernel.get_component('agent_router')` a las skills que tengan permiso `core_read`, para que puedan buscar agentes por capacidad.
- Publica eventos v2: `sage.skill.invoked`, `sage.skill.completed`, `sage.skill.failed`.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-005.

---

## M06 — Cache Layer

**Problema que resuelve:** cada llamada a un provider cuesta dinero y tiempo. No hay cache — si dos comandos son idénticos, se pagan dos veces. La memoria SQLite guarda registros pero no respuestas.

**Beneficio:** reduce costo y latencia. Para comandos repetitivos (mismo prompt → misma respuesta), hit rate puede ser 30-60%.

**Nivel de prioridad:** Media

**Dependencias:**
- v2 internos: M02 (Event Bridge — para invalidar cache ante `MEMORY_SAVED` o `KNOWLEDGE_DOCUMENT_ADDED`)
- v1 core read-only: `providers.provider_router` (para interceptar — ver integración)
- Externos: `sqlite3` (L2), `cachetools` (L1 LRU)

**Riesgo:**
- Cache staling: si el contexto cambió pero el comando es igual, la respuesta cacheada es incorrecta. Mitigación: clave de cache = hash(prompt + contexto relevante); invalidación por evento.
- Memoria: L1 puede crecer. Mitigación: LRU con bound configurable (default 1000 entradas).
- Privacidad: si dos usuarios diferentes envían el mismo prompt, no deben compartir cache. Mitigación: `user_id` parte de la clave.

**Archivos nuevos:**
- `cache/__init__.py`
- `cache/layer.py` — `CacheLayer` class (L1 + L2)
- `cache/l1_memory.py` — L1 LRU en memoria
- `cache/l2_sqlite.py` — L2 persistente en `~/.sage_os/cache.db`
- `cache/key_builder.py` — construcción de claves
- `cache/invalidator.py` — suscripción a eventos para invalidación

**Integración con el núcleo:**
- NO intercepta `provider_router.generate_text()` (requeriría modificar el dispatcher o el provider_router).
- En su lugar, expone `cache.layer.get(key)` y `cache.layer.set(key, value, ttl)`.
- El Context Manager (cuando exista) o los plugins pueden llamar al cache antes de llamar al provider.
- Suscribe al Event Bridge para invalidar caches cuando:
  - `sage.knowledge.document_added` — invalida caches de RAG.
  - `sage.memory.saved` — invalida caches de sesión.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-006.

---

## M07 — Rate Limiter

**Problema que resuelve:** los providers tienen rate limits (Grok, Gemini). Hoy no hay protección — un usuario puede disparar 100 comandos y agotar la cuota. El dispatcher las encola pero todas se ejecutan.

**Beneficio:** protege cuotas de API; protege al sistema de abuso; permite multiusuario sin que un usuario starvation a otros.

**Nivel de prioridad:** Media

**Dependencias:**
- v2 internos: M02 (Event Bridge)
- v1 core read-only: ninguno
- Externos: `redis` (opcional, para distribución), `asyncio_throttle` o implementación propia

**Riesgo:**
- Si el limiter es muy estricto, comandos legítimos se bloquean. Mitigación: configuración por usuario y por provider; bypass para admin.
- Si el limiter cae, no debe bloquear el sistema. Mitigación: fail-open (si el limiter no responde, se permite el comando y se loguea).

**Archivos nuevos:**
- `rate_limiter/__init__.py`
- `rate_limiter/limiter.py` — `RateLimiter` class (token bucket)
- `rate_limiter/policies.py` — políticas por usuario / provider / ventana
- `rate_limiter/storage.py` — backend (in-memory por defecto, Redis opcional)
- `rate_limiter/middleware.py` — middleware que plugins pueden usar para envolver llamadas

**Integración con el núcleo:**
- NO intercepta el dispatcher ni el provider_router.
- Expone `rate_limiter.check_and_consume(key, cost)` que los plugins pueden llamar antes de invocar un provider.
- Suscribe al Event Bridge para trackear uso: cada `sage.provider.call` consume tokens del bucket del usuario.
- Publica `sage.rate_limit.threshold_reached` cuando un bucket está al 80%.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-007.

---

## M08 — Notification System

**Problema que resuelve:** hoy no hay forma de que SAGE avise a un humano cuando algo importante pasa (comando fallido, cuota agotada, misión completada). El dashboard web muestra estado pero no envía alertas.

**Beneficio:** SAGE puede notificar proactivamente a usuarios y admins. Habilita uso desatendido (no need to mirar el dashboard).

**Nivel de prioridad:** Media

**Dependencias:**
- v2 internos: M01, M02, M03
- v1 core read-only: ninguno
- Externos: `aiosmtplib` (email), `httpx` (webhooks), `slack-sdk` (Slack), `pywebpush` (web push)

**Riesgo:**
- Spam: si las reglas son malas, el usuario recibe 100 notificaciones por minuto. Mitigación: digest mode, rate limiting por canal, suppress duplicates.
- Credenciales: guardar tokens de Slack/email. Mitigación: en `~/.sage_os/notifications/credentials.enc`, cifrados con clave derivada del user password.
- Fallos silenciosos: si el webhook del usuario está caído, SAGE no se entera. Mitigación: retry con backoff; si falla 5 veces, desactivar canal y notificar via canal alternativo.

**Archivos nuevos:**
- `notifications/__init__.py`
- `notifications/dispatcher.py` — `NotificationDispatcher` class
- `notifications/channels/` — canal por archivo:
  - `notifications/channels/email.py`
  - `notifications/channels/webhook.py`
  - `notifications/channels/slack.py`
  - `notifications/channels/desktop.py` (via OS notification)
  - `notifications/channels/in_app.py` ( WebSocket Hub)
- `notifications/rules.py` — motor de reglas (evento → canal + template)
- `notifications/templates/` — Jinja2 templates por tipo de evento
- `notifications/digest.py` — modo digest (agrupa notificaciones por ventana)
- `~/.sage_os/notifications/credentials.enc`
- `~/.sage_os/notifications/rules.json`

**Integración con el núcleo:**
- Suscribe al Event Bridge con wildcard.
- Cada evento v2 pasa por el motor de reglas; si matchea, se encola para envío.
- Publica `sage.notification.dispatched` y `sage.notification.failed`.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-008.

---

## M09 — REST API v2 + WebSocket Hub

**Problema que resuelve:** la API v1 actual (`/api/kernel/status`, `/api/command/execute`, etc.) es mínima, sin versión, sin auth, sin documentación OpenAPI. No hay forma de exponer capacidades v2 (plugins, knowledge, skills) sin ensuciar el server.py existente.

**Beneficio:** API versionada, documentada, autenticada; WebSocket para eventos en tiempo real; superficie limpia para SDKs y dashboard v2.

**Nivel de prioridad:** Alta

**Dependencias:**
- v2 internos: M01, M02, M03 (todos — los endpoints v2 exponen capacidades v2)
- v1 core read-only: `kernel` (vía Plugin Runtime, para endpoints legacy compat)
- Externos: `fastapi` (ya instalado), `pyjwt` (auth), `openapi` (auto-doc)

**Riesgo:**
- Si los routers v2 se montan en el mismo FastAPI app que v1, un bug en v2 puede tirar v1. Mitigación: montar routers v2 en un sub-app FastAPI separado, mountado via `app.mount("/v2", v2_app)`.
- Auth puede romper clientes existentes si se vuelve obligatoria. Mitigación: auth opt-in; endpoints v2 la requieren, v1 la ignoran.

**Archivos nuevos:**
- `api_v2/__init__.py`
- `api_v2/app.py` — FastAPI app v2 separado
- `api_v2/routers/` — un router por dominio:
  - `api_v2/routers/plugins.py`
  - `api_v2/routers/knowledge.py`
  - `api_v2/routers/skills.py`
  - `api_v2/routers/cache.py`
  - `api_v2/routers/notifications.py`
  - `api_v2/routers/profiles.py`
  - `api_v2/routers/audit.py`
  - `api_v2/routers/telemetry.py`
  - `api_v2/routers/costs.py`
  - `api_v2/routers/backups.py`
  - `api_v2/routers/workflows.py`
  - `api_v2/routers/admin.py`
  - `api_v2/routers/search.py`
- `api_v2/auth.py` — JWT + API key
- `api_v2/schemas.py` — modelos pydantic de request/response
- `api_v2/middleware.py` — auth middleware, rate limit middleware, request ID
- `api_v2/openapi_tags.py` — metadatos para Swagger UI

**Integración con el núcleo:**
- Montado via `app.mount("/v2", v2_app)` en el web server existente (1 línea en `web/server.py` — pero como no podemos modificar ese archivo, se hace via plugin: un plugin "api_v2_mount" que obtiene `kernel.get_component('web_server')` y llama `mount()` en su `on_load`).
- Alternativa sin tocar `web/server.py`: FastAPI app v2 separado en otro puerto (8001), que se lanza como sidecar.
- WebSocket Hub: endpoint `/ws/v2` en el mismo app v2; suscribe al internal_bus del Event Bridge y pushea eventos a clientes conectados.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-009.

---

## M10 — Telemetry & Audit

**Problema que resuelve:** no hay métricas, no hay traces, no hay log de auditoría. Debuggear un comando fallido requiere reproducirlo. Auditar quién hizo qué es imposible.

**Beneficio:** observabilidad completa; SRE-ready; compliance-ready (audit log es append-only).

**Nivel de prioridad:** Media

**Dependencias:**
- v2 internos: M02 (Event Bridge — fuente de eventos)
- v1 core read-only: `~/.sage_os/memory.db` (solo lectura para correlación)
- Externos: `prometheus-client`, `opentelemetry-sdk`, `sqlite3` (audit log)

**Riesgo:**
- Overhead: cada evento genera métricas + trace + audit. Mitigación: sampling configurable (p.ej. trace al 10%).
- Tamaño del audit log: crece para siempre. Mitigación: rotación por tamaño + retención configurable.
- Privacidad: el audit log puede contener datos sensibles. Mitigación: redacción de PII por defecto.

**Archivos nuevos:**
- `telemetry/__init__.py`
- `telemetry/metrics.py` — `MetricsCollector` (Prometheus)
- `telemetry/tracer.py` — `Tracer` (OpenTelemetry)
- `telemetry/exporters/` — exporters (Prometheus, OTLP, console)
- `telemetry/sampling.py` — políticas de sampling
- `audit/__init__.py`
- `audit/log.py` — `AuditLog` (append-only, SQLite WAL)
- `audit/redactor.py` — redacción de PII
- `audit/rotator.py` — rotación por tamaño
- `~/.sage_os/audit/audit.log.db`
- `~/.sage_os/telemetry/prometheus.prom`

**Integración con el núcleo:**
- Telemetry suscribe al Event Bridge con wildcard; cada evento → métrica + span.
- Audit Log suscribe a eventos sensibles (command_executed, command_failed, plugin_loaded, plugin_unloaded, config_changed — aunque este último no existe en v1, se puede emitir via el Plugin Runtime).
- Exponen endpoints en REST v2: `/api/v2/telemetry/metrics`, `/api/v2/audit`.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-010.

---

## M11 — Cost Tracker

**Problema que resuelve:** SAGE llama a providers pagos (Grok, Gemini) sin trackear costo. No hay forma de saber cuánto se gastó por usuario, por sesión, por skill.

**Beneficio:** visibilidad de costos; permite chargeback; alertas de presupuesto.

**Nivel de prioridad:** Media

**Dependencias:**
- v2 internos: M02 (Event Bridge — escucha `sage.provider.call`)
- v1 core read-only: ninguno
- Externos: `sqlite3`, `pydantic`

**Riesgo:**
- Precios cambian: la tabla de precios debe ser actualizable sin tocar código. Mitigación: precios en `~/.sage_os/costs/pricing.json`, versionado por fecha.
- Si el tracker cae, se pierden eventos de costo. Mitigación: subscripción durable via DLQ del Event Bridge.

**Archivos nuevos:**
- `costs/__init__.py`
- `costs/tracker.py` — `CostTracker` class
- `costs/pricing.py` — cargador de `pricing.json`
- `costs/aggregator.py` — agregaciones por user / session / skill / período
- `costs/alerts.py` — alertas de presupuesto
- `~/.sage_os/costs/costs.db`
- `~/.sage_os/costs/pricing.json`

**Integración con el núcleo:**
- Suscribe al Event Bridge.
- Cada `sage.provider.call` con metadata de tokens → lookup de precio → inserta en DB.
- Publica `sage.cost.threshold_reached` cuando un usuario supera su budget.
- Endpoints en REST v2: `/api/v2/costs`.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-011.

---

## M12 — Backup System

**Problema que resuelve:** `~/.sage_os/` contiene memory.db, knowledge_db, audit log, configs — todo el estado de SAGE. No hay backup automático. Un fallo de disco pierde todo.

**Beneficio:** recuperación ante desastres; snapshots point-in-time; exportación para migración.

**Nivel de prioridad:** Baja

**Dependencias:**
- v2 internos: M02 (Event Bridge — para snapshots consistentes via pause del bus)
- v1 core read-only: filesystem de `~/.sage_os/`
- Externos: `tarfile`, `sqlite3` (para backup consistente via `VACUUM INTO`)

**Riesgo:**
- Backup durante operación activa puede ser inconsistente. Mitigación: usar `sqlite3 VACUUM INTO` para memory.db; para knowledge_db (ChromaDB), pausa breve del Event Bridge para snapshot atomic.
- Tamaño: backups crecen. Mitigación: compresión + retención (mantener N últimos).

**Archivos nuevos:**
- `backup/__init__.py`
- `backup/manager.py` — `BackupManager` class
- `backup/snapshot.py` — captura consistente de todos los stores
- `backup/restore.py` — restauración point-in-time
- `backup/scheduler.py` — cron propio (no depende del Cron Scheduler v2.1)
- `backup/retention.py` — política de retención
- `~/.sage_os/backups/` — directorio de snapshots

**Integración con el núcleo:**
- Lee `~/.sage_os/memory.db` via `VACUUM INTO` (no toca el archivo en vivo).
- Lee `~/.sage_os/knowledge_db/` con pausa breve del Event Bridge (los plugins esperan; el core sigue).
- NO restaura en caliente — la restauración requiere que SAGE esté detenido.

**Mini-RFC:** ver `RFC_FUTURE_MODULES.md` § RFC-012.

---

## Tabla resumen de dependencias

```
M01 Plugin Runtime ────────────┐
M02 Event Bridge ──────────────┤── fundamentos
M03 Lateral Registry ──────────┘
       │
       ├── M04 Knowledge Base ──── M05 Skills
       │                          ── M06 Cache
       │                          ── M07 Rate Limiter
       │                          ── M08 Notifications
       │
       ├── M09 REST API v2 + WS Hub ── expone todos los módulos v2
       │
       └── M10 Telemetry & Audit ── observa todos
          M11 Cost Tracker ──────── observa providers
          M12 Backup ────────────── lee filesystem
```

**Orden óptimo de implementación:**
1. M01 + M02 + M03 (fundamentos, en paralelo)
2. M04 + M05 (capacidades core, en paralelo)
3. M09 (interfaces — sin esto, los módulos v2 no se pueden usar externamente)
4. M06 + M07 + M08 (capacidades complementarias, en paralelo)
5. M10 + M11 + M12 (operaciones, en paralelo)

---

## Próximos pasos

- Revisión por parte del Arquitecto: priorizar qué módulos entran en v2.0 vs v2.1.
- Para cada módulo aprobado, abrir un RFC formal en `RFC_FUTURE_MODULES.md`.
- Asignar ingenieros: los módulos de capa 1 y 2 pueden ser desarrollados por agentes externos (no Cascade, no Claude A, no Runtime Engineer — todos ocupados con el core).
- Definir contratos de testing: cada módulo v2 debe tener su propia suite de tests, independiente de los tests del core.

— GLM, Arquitecto de Evolución de SAGE
